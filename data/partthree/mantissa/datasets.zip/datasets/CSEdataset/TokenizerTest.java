import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;
import static java.util.Arrays.asList;
import java.util.ArrayList;
import java.util.List;

public class TokenizerTest{

	@Test
	public void testTokenize() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Tokenizer");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("tokenize", String.class);  
		List<String> tokens = asList("this", "is", "a", "test");
		assertEquals("Wrong answer!", tokens, m.invoke(c, "this is a test"));
	}
} 