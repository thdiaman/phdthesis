public class Md5{
    public String md5Sum(String i){}
} 