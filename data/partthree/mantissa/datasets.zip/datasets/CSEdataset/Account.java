public class Account{
    public void deposit(double d){}
    public void withdraw(double w){}
    public double getBalance(){}
}