import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class GcdTest{

	@Test
	public void testGcd1() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 1, m.invoke(c, 1, 3));
	}
	@Test
	public void testGcd2() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 1, m.invoke(c, 4, 7));
	}
	@Test
	public void testGcd3() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 2, m.invoke(c, 14, 22));
	}
	@Test
	public void testGcd4() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 3, m.invoke(c, 15, 18));
	}
	
	@Test
	public void testGcd5() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 6, m.invoke(c, 12, 18));
	}
	
	@Test
	public void testGcd6() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 4, m.invoke(c, 400, 404));
	}
	
	@Test
	public void testGcd7() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Gcd");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("", int.class, int.class);  
		assertEquals("Wrong answer!", 8, m.invoke(c, 8, 16));
	}
} 