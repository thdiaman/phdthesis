import static org.junit.Assert.assertEquals;
import org.junit.Test;
import java.lang.reflect.*;

public class Md5Test{

	@Test
	public void testMd5Sum() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Md5");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("md5Sum", String.class);
		assertEquals("d41d8cd98f00b204e9800998ecf8427e", m.invoke(c, ""));
	}
} 