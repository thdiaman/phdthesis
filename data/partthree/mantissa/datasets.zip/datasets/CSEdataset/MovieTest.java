import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class MovieTest{

	@Test
	public void testMovie() throws Exception{
		int m_index = 1;
		Class<?> clazz = Class.forName("Movie");
		Constructor ct = clazz.getDeclaredConstructor(String.class, int.class);
		Object c = ct.newInstance("test", 1);
		Method m = clazz.getDeclaredMethod("getTitle");			
		assertEquals("test", m.invoke(c));
	}
	
} 