public class Stack{
    public void push(Object o){}
    public Object pop(){}
} 