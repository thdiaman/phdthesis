public class _{
    public void sort(int[] i){}
} 