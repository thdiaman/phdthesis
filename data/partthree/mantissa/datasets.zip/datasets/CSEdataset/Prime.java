public class _{
    public boolean checkPrime(int i){}
} 