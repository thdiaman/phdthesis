import static org.junit.Assert.assertTrue;

import org.junit.Test;
import java.lang.reflect.*;

public class SortTest{

	@Test
	public void testSort() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Sort");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("sort", int[].class);  
		int[] array = new int[] { 3, 2, 1 };
		m.invoke(c, array);
		assertTrue(array[0] < array[1] && array[1] < array[2]);
	}
} 