public class Article{
    public void setId(int id){}
    public int getId(){}
    public void setName(String name){}
    public String getName(){}
    public void setPrice(double price){}
	public double getPrice(){}
} 