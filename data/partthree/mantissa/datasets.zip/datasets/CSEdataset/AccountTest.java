import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class AccountTest{

	@Test
	public void testAccount() throws Exception{

		int m_index = 0;
		Class<?> clazz = Class.forName("Account");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("deposit", double.class);  
		m.invoke(c, 1000.0);		
		m_index = 1;
		m = clazz.getDeclaredMethod("withdraw", double.class);   
		m.invoke(c, 500.0);
		m_index = 2;
		m = clazz.getDeclaredMethod("getBalance");
		assertEquals("Wrong string!", 500.0, m.invoke(c));
	}
} 