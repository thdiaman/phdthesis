import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class PrimeTest{

	@Test
	public void testIsPrime1() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Prime");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("checkPrime", int.class);   
		assertEquals("Wrong answer", true, m.invoke(c, 5));
	}
	@Test
	public void testIsPrime2() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("_");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("checkPrime", int.class);   
		assertEquals("Wrong answer", false, m.invoke(c, 39));
	}
	@Test
	public void testIsPrime3() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("_");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("checkPrime", int.class);   
		assertEquals("Wrong answer", true, m.invoke(c, 59));
	}
} 