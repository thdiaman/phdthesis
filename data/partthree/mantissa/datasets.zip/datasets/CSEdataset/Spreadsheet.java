public class Spreadsheet{
    public void put(String i, String j){}
    public String get(String i){}
} 