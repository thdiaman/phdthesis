public class _{
    public List<String> tokenize(String s){}
} 