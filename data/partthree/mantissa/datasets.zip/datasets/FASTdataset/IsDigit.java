public class _{
    public boolean isDigit(char i){}
} 