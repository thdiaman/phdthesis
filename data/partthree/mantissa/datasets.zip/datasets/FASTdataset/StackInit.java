public class Stack{
    public Stack(int size){}
    public void push(int o){}
    public int pop(){}
} 