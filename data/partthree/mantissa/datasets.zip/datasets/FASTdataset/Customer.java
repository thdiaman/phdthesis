public class Customer{
    public void setName(String n){}
    public String getName(){}
    public void setId(int id){}
    public int getId(){}
    public void setBirthday(Date d){}
    public Date getBirthday(){}
} 