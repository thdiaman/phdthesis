public class FinancialCalculator{
    public void setPaymentsPerYear(int i){}
    public void setNumPayments(int i){}
    public void setInterest(float i){}
    public void setPresentValue(float i){}
    public void setFutureValue(float i){}
    public float getPayment(){}
} 