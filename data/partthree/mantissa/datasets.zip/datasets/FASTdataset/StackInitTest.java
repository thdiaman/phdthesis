import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.Object;
import java.lang.reflect.*;

public class StackInitTest{

	@Test
	public void testPushPop1() throws Exception{

		int m_index = 1;
		Class<?> clazz = Class.forName("StackInit");
		Object c = clazz.getDeclaredConstructor(int.class).newInstance(5);
		Method m = clazz.getDeclaredMethod("push", int.class);
		m.invoke(c, 3);	  
		m.invoke(c, 4);	
		m_index = 2;
		m = clazz.getDeclaredMethod("pop");
		assertEquals("Wrong answer!", 4, m.invoke(c));
	}
	
	// one more test for generic types
	@Test
	public void testPushPop2() throws Exception{

		int m_index = 1;
		Class<?> clazz = Class.forName("StackInit");
		Object c = clazz.getDeclaredConstructor(int.class).newInstance(5);
		Method m = clazz.getDeclaredMethod("push", java.lang.Object.class);
		m.invoke(c, 3);	  
		m.invoke(c, 4);	
		m_index = 2;
		m = clazz.getDeclaredMethod("pop");
		assertEquals("Wrong answer!", 4, m.invoke(c));
	}
} 