import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class FibonacciTest{

	@Test
	public void testFibonacci1() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 1, m.invoke(c, 1));
	}
	@Test
	public void testFibonacci2() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 1, m.invoke(c, 2));
	}
	@Test
	public void testFibonacci3() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 2, m.invoke(c, 3));
	}
	@Test
	public void testFibonacci4() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 3, m.invoke(c, 4));
	}
	
	@Test
	public void testFibonacci5() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 5, m.invoke(c, 5));
	}
	
	@Test
	public void testFibonacci6() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 8, m.invoke(c, 6));
	}
	
	@Test
	public void testFibonacci7() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Fibonacci");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("Fibonacci", int.class);  
		assertEquals("Wrong answer!", 13, m.invoke(c, 7));
	}
} 