public class _{
    public boolean isPalindrome(String s){}
} 