import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class FinancialCalculatorTest{

	@Test
	public void testPayment() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("FinancialCalculator");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setPaymentsPerYear", int.class);
		m.invoke(c, 12);	
		m_index = 1;
		m = clazz.getDeclaredMethod("setNumPayments", int.class);
		m.invoke(c, 360);
		m_index = 2;
		m = clazz.getDeclaredMethod("setInterest", float.class);
		m.invoke(c, 10.0);
		m_index = 3;
		m = clazz.getDeclaredMethod("setPresentValue", float.class);
		m.invoke(c, 14000.0);
		m_index = 4;
		m = clazz.getDeclaredMethod("setFutureValue", float.class);
		m.invoke(c, 0.0);
		m_index = 5;
		m = clazz.getDeclaredMethod("getPayment");
		assertEquals(-122.86, (double)m.invoke(c), 0.001);
	}
	
} 