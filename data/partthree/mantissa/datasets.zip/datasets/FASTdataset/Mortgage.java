public class Mortgage{
    public void calculateMortgage(double rate, int months, int principal){}
} 