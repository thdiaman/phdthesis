public class _{
	public boolean isPrime(int i){}
} 