import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;
import java.lang.reflect.*;

public class IsDigitTest{

	@Test
	public void testIsDigit1() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsDigit");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isDigit", char.class);
		assertTrue((boolean)m.invoke(c, '2'));
	}
	
	@Test
	public void testIsDigit2() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsDigit");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isDigit", char.class);
		assertFalse((boolean)m.invoke(c, 'a'));
	}
} 