public class _{
    public boolean isLeapYear(int i){}
} 