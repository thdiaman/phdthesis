import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class SumArrayTest{

	@Test
	public void testSum() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("SumArray");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("sumArray", int[].class);  
		int[] array = new int[] { 1, 2, 3 };
		assertEquals(6, m.invoke(c, array));
	}
} 