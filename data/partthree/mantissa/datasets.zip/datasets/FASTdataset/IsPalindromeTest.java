import org.junit.Test;
import java.lang.reflect.*;

public class IsPalindromeTest{

	@Test
	public void testIsPalindrome() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsPalindrome");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isPalindrome", String.class); 
		String s = "abcba";
		m.invoke(c, s);
		//or
		// assertTrue((boolean)m.invoke(c, "abcba"));
	}
} 