import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.util.Date;
import java.lang.reflect.*;

public class CustomerTest{

	@Test
	public void testName() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Customer");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setName", String.class);
		m.invoke(c, "Nikos");	
		m_index = 1;
		m = clazz.getDeclaredMethod("getName");			
		assertEquals("Nikos", m.invoke(c));
	}
	
	@Test
	public void testId() throws Exception{
		int m_index = 2;
		Class<?> clazz = Class.forName("Customer");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setId", int.class);
		m.invoke(c, 1);	
		m_index = 3;
		m = clazz.getDeclaredMethod("getId");			
		assertEquals(1, m.invoke(c));
	}
	
	@Test
	public void testBirthday() throws Exception{
		int m_index = 4;
		Class<?> clazz = Class.forName("Customer");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("setBirthday", java.util.Date.class);
		m.invoke(c, new Date(1980, 10, 4));	
		m_index = 5;
		m = clazz.getDeclaredMethod("getBirthday");			
		assertEquals(new Date(1980, 10, 4), m.invoke(c));
	}
	
} 