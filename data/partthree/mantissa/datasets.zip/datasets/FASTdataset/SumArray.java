public class _{
    public int sumArray(int[] i){}
} 