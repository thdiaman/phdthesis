public class CreditCardValidator{
	public boolean isValid(String i){}
} 