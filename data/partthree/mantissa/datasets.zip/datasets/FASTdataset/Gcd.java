public class _{
	public int gcd(int i, int j){}
} 