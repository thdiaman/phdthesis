public class _{
    public int Fibonacci(int i){}
} 