import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;
import java.lang.reflect.*;

public class PrimeTest{

	@Test
	public void testIsPrime1() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Prime");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isPrime", int.class);
		assertTrue((boolean)m.invoke(c, 2));
	}
	
	@Test
	public void testIsPrime2() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("Prime");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isPrime", int.class);
		assertFalse((boolean)m.invoke(c, 4));
	}
} 