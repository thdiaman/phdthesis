import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;
import java.lang.reflect.*;

public class IsLeapYearTest{

	@Test
	public void testIsLeapYear1() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsLeapYear");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isLeapYear", int.class);
		assertTrue((boolean)m.invoke(c, 1980));
	}
	
	@Test
	public void testIsLeapYear2() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsLeapYear");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isLeapYear", int.class);
		assertFalse((boolean)m.invoke(c, 1987));
	}
	
	@Test
	public void testIsLeapYear3() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsLeapYear");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isLeapYear", int.class);
		assertTrue((boolean)m.invoke(c, 2000));
	}
	
	@Test
	public void testIsLeapYear4() throws Exception{
		int m_index = 0;
		Class<?> clazz = Class.forName("IsLeapYear");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("isLeapYear", int.class);
		assertFalse((boolean)m.invoke(c, 1990));
	}
} 