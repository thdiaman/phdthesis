public class Stack{
    public void push(int o){}
    public int pop(){}
} 