import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.Object;
import java.lang.reflect.*;

public class StackTest{
	
	@Test
	public void testPushPop() throws Exception{

		int m_index = 0;
		Class<?> clazz = Class.forName("Stack");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("push", java.lang.Object.class);
		m.invoke(c, 3);	  
		m.invoke(c, 4);	
		m_index = 1;
		m = clazz.getDeclaredMethod("pop");
		assertEquals("Wrong answer!", 4, m.invoke(c));
	}
} 