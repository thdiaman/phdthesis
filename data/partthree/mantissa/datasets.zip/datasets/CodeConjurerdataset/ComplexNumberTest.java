import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class ComplexNumberTest{

	@Test
	public void testComplexNumber() throws Exception{

		Class<?> clazz = Class.forName("ComplexNumber");
		Constructor ct = clazz.getDeclaredConstructor(double.class, double.class);
		Object c = ct.newInstance(1.0,2.0);
		int m_index = 1;
		Method m = clazz.getDeclaredMethod("getRealPart");  
		assertEquals("Wrong answer!", 1.0, m.invoke(c));
		m_index = 2;
		m = clazz.getDeclaredMethod("getImaginaryPart");  
		assertEquals("Wrong answer!", 2.0, m.invoke(c));        
	}
} 