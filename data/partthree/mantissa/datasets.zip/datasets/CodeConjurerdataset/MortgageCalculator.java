public class MortgageCalculator{
    public void setRate(double i){}
    public void setPrincipal(double i){}
    public void setYears(int i){}
    public double getMonthlyPayment(){}
} 