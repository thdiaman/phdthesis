public class Calculator{
    public int add(int i, int j){}
    public int sub(int i, int j){}
    public int div(int i, int j){}
    public int mult(int i, int j){}
} 