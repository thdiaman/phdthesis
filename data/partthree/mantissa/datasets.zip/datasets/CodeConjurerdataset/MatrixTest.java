import static org.junit.Assert.assertEquals;

import org.junit.Test;
import java.lang.reflect.*;

public class MatrixTest{

	@Test
	public void testMatrix() throws Exception{

		Class<?> clazz = Class.forName("Matrix");
		Object c = clazz.getDeclaredConstructor(int.class,int.class).newInstance(2,2);
		int m_index = 1;
		Method m = clazz.getDeclaredMethod("set", int.class, int.class, double.class);  
		m.invoke(c, 0, 0, 1);		
		m_index = 2;
		m = clazz.getDeclaredMethod("get", int.class, int.class);   
		assertEquals("Wrong answer!", 1, m.invoke(c, 0, 0));
	}
} 