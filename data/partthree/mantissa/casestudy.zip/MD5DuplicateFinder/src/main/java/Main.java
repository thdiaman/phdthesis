import java.io.File;
import java.io.IOException;

@SuppressWarnings("unchecked")
public class Main {

	public static void main(String[] args) throws IOException {
		createDocumentSet("documents.txt", "documents");
		System.out.println(fileExists("documents.txt", "documents" + File.separator + "example.txt"));
	}

	public static void createDocumentSet(String setFilename, String folderPath) throws IOException {
		SerializableSet set = new SerializableSet();
		for (File string : new File(folderPath).listFiles()) {
			String content = FileTools.read(string.getAbsolutePath());
			String md5String = Md5.md5Sum(content);
			set.add(md5String);
		}
		FileTools.write(set.serialize(), setFilename);
	}

	public static boolean fileExists(String setFilename, String filename) {
		SerializableSet set = new SerializableSet();
		set.deserialize(FileTools.read(setFilename));
		String content = FileTools.read(filename);
		return set.contains(Md5.md5Sum(content));
	}

}
