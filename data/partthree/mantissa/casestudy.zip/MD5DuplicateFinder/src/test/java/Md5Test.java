import static org.junit.Assert.assertEquals;
import org.junit.Test;
import java.lang.reflect.*;

public class Md5Test {
	@Test
	public void testMd5Sum() throws Exception {
		int m_index = 0;
		Class<?> clazz = Class.forName("Md5");
		Method m = clazz.getDeclaredMethod("md5Sum", String.class);
		assertEquals("c2a9ce57e8df081b4baad80d81868bbb", m.invoke(null, "This is my string"));
	}
}
