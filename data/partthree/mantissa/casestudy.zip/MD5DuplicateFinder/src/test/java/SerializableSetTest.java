import static org.junit.Assert.assertEquals;
import org.junit.Test;
import java.lang.reflect.*;

public class SerializableSetTest {
	@Test
	public void testSerialization() throws Exception {
		int m_index = 0;
		Class<?> clazz = Class.forName("SerializableSet");
		Object c = clazz.newInstance();
		Method m = clazz.getDeclaredMethod("serialize");
		Object serializedSet = m.invoke(c);
		m_index = 1;
		m = clazz.getDeclaredMethod("deserialize", String.class);
		Object deserializedSet = m.invoke(c, serializedSet);
		assertEquals(c, deserializedSet);
	}
}
