The dataset includes the following files:
 * original_texts.txt -- raw requirement sentences
 * revised_all.conll.ann -- revised annotations of all requirements (merged following discussions with annotators)
 * revised_all.conll.txt -- tokenized version of the requirement sentences
 * revised_all_NNobjs+noPrepProp.conll.ann -- same annotations as above, but without syntactic head words of prepositional phrases marked as properties (removed) or objects (moved to nominal head)
 * revised_all_NNobjs+noPrepProp.conll.txt -- text file version of above for completeness (identical to revised_all.conll.txt)
