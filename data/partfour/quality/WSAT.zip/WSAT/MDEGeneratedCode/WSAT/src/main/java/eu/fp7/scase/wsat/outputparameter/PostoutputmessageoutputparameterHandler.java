/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.outputparameter;


import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.outputmessage.JavaoutputmessageModel;

/* This class processes POST requests for outputparameter resources and creates the hypermedia to be returned to the client*/

public class PostoutputmessageoutputparameterHandler{


    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavaoutputparameterModel oJavaoutputparameterModel;
    private JavaoutputmessageModel oJavaoutputmessageModel;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public PostoutputmessageoutputparameterHandler(String authHeader, int outputmessageId, JavaoutputparameterModel oJavaoutputparameterModel, UriInfo oApplicationUri){
        this.oJavaoutputparameterModel = oJavaoutputparameterModel;
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
        oJavaoutputmessageModel = new JavaoutputmessageModel();
        oJavaoutputmessageModel.setoutputmessageId(outputmessageId);
        oJavaoutputparameterModel.setoutputmessage(this.oJavaoutputmessageModel);
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
    }

    public JavaoutputparameterModel postJavaoutputparameterModel(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

        return createHypermedia(oHibernateController.postoutputparameter(oJavaoutputparameterModel));
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client so as it will be able to forward the application state in a valid way.*/
    public JavaoutputparameterModel createHypermedia(JavaoutputparameterModel oJavaoutputparameterModel){

        /* Create hypermedia links towards this specific outputparameter resource. These must be GET and POST as it is prescribed in the meta-models.*/
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Get all outputparameters of this outputmessage", "GET", "Sibling"));
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Create a new outputparameter", "POST", "Sibling"));

        /* Then calculate the relative path to any resources that are related of this one and add the according hypermedia links to the Linklist.*/
        String oRelativePath;
        oRelativePath = oApplicationUri.getPath().replaceAll("multioutputparameterManager/", "multioutputparameter/");
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavaoutputparameterModel.getoutputparameterId()), oJavaoutputparameterModel.getname(), "GET", "Child", oJavaoutputparameterModel.getoutputparameterId()));
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavaoutputparameterModel.getoutputparameterId()), oJavaoutputparameterModel.getname(), "PUT", "Child", oJavaoutputparameterModel.getoutputparameterId()));
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavaoutputparameterModel.getoutputparameterId()), oJavaoutputparameterModel.getname(), "DELETE", "Child", oJavaoutputparameterModel.getoutputparameterId()));

        /* Finally, calculate the relative path towards the resources of which this one is related.
        Then add hypermedia links for each one of them*/
        this.oJavaoutputmessageModel = HibernateController.getHibernateControllerHandle().getoutputmessage(this.oJavaoutputmessageModel);
        oRelativePath = String.format("soapoperation/%d/%s", this.oJavaoutputmessageModel.getsoapoperation().getsoapoperationId(), oApplicationUri.getPath().replaceAll("multioutputparameterManager/", ""));
        int iLastSlashIndex = String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).lastIndexOf("/");
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Delete the parent outputmessage", "DELETE", "Parent"));
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Get the parent outputmessage", "GET", "Parent"));
        oJavaoutputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Update the outputmessage", "PUT", "Parent"));
        return oJavaoutputparameterModel;
    }
}
