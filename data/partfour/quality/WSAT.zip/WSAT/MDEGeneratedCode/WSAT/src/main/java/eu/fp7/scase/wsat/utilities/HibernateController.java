/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.utilities;


import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import java.util.Set;
import java.util.HashSet;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.sun.jersey.core.spi.factory.ResponseBuilderImpl;

import eu.fp7.scase.wsat.restmethod.JavarestmethodModel;
import eu.fp7.scase.wsat.soapservice.JavasoapserviceModel;
import eu.fp7.scase.wsat.outputmessage.JavaoutputmessageModel;
import eu.fp7.scase.wsat.restparameter.JavarestparameterModel;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterModel;
import eu.fp7.scase.wsat.outputparameter.JavaoutputparameterModel;
import eu.fp7.scase.wsat.inputmessage.JavainputmessageModel;
import eu.fp7.scase.wsat.resource.JavaresourceModel;
import eu.fp7.scase.wsat.account.JavaaccountModel;
import eu.fp7.scase.wsat.soapoperation.JavasoapoperationModel;
import eu.fp7.scase.wsat.restservice.JavarestserviceModel;

/* HibernateController class is responsible to handle the low level activity between Hibernate and the service database.
 You may not alter existing functions, or the service may not function properly.
 Should you need more functions these could be added at the end of this file.
 You may add any exception handling to existing and/or new functions of this file.*/

public class HibernateController{

    private static HibernateController oHibernateController = new HibernateController();

    /* Since the class follows the singleton design pattern its constructor is kept private. The unique instance of it is accessed through its public API "getHibernateControllerHandle()".*/
    private HibernateController(){}

    /* Since this class follows the singleton design pattern, this function offers to the rest of the system a handle to its unique instance.*/
    public static HibernateController getHibernateControllerHandle(){
        return oHibernateController;
    }

	/* This function performs the actual authentication activity by looking up in the database wether the request's user is an authenticated user*/
	 public JavaaccountModel authenticateUser(JavaaccountModel oJavaaccountModel)
	 {
		 try
		 {
			//create a new session and begin the transaction
		    Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
			Transaction hibernateTransaction = hibernateSession.beginTransaction();
			
			//create the query in HQL language
			String strQuery = String.format("FROM JavaaccountModel WHERE (username = '%s' AND password = '%s')", oJavaaccountModel.getusername() , oJavaaccountModel.getpassword());
			Query  hibernateQuery = hibernateSession.createQuery(strQuery);
			
			oJavaaccountModel = null;
			
			//retrieve the unique result, if there is a result at all
			oJavaaccountModel = (JavaaccountModel) hibernateQuery.uniqueResult();
			
			if(oJavaaccountModel == null)
			{
	    		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
			}
			
			//commit and terminate the session
			hibernateTransaction.commit();
			hibernateSession.close();
			
			//return the JavaaccountModel of the authenticated user, or null if authentication failed
			return oJavaaccountModel ;
		}
		catch (HibernateException exception)
		{
			System.out.println(exception.getCause());

			ResponseBuilderImpl builder = new ResponseBuilderImpl();
			builder.status(Response.Status.BAD_REQUEST);
			builder.entity(String.format("%s",exception.getCause()));
			Response response = builder.build();
			throw new WebApplicationException(response);
		}
	 }

    /* This function handles the low level JPA activities so as to add a new restmethod resource to the service database.*/
    public JavarestmethodModel postrestmethod(JavarestmethodModel oJavarestmethodModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new restmethod to database*/
        int restmethodId = (Integer) hibernateSession.save(oJavarestmethodModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavarestmethodModel with updated restmethodId*/
        oJavarestmethodModel.setrestmethodId(restmethodId);
        return oJavarestmethodModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing restmethod resource of the service database.*/
    public JavarestmethodModel putrestmethod(JavarestmethodModel oJavarestmethodModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing restmethod of the database*/
        hibernateSession.update(oJavarestmethodModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestmethodModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing restmethod resource from the service database.*/
    public JavarestmethodModel getrestmethod(JavarestmethodModel oJavarestmethodModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing restmethod from the database*/
        oJavarestmethodModel = (JavarestmethodModel) hibernateSession.get(JavarestmethodModel.class, oJavarestmethodModel.getrestmethodId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestmethodModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing restmethod resource from the service database.*/
    public JavarestmethodModel deleterestmethod(JavarestmethodModel oJavarestmethodModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing restmethod from the database*/
        oJavarestmethodModel = (JavarestmethodModel) hibernateSession.get(JavarestmethodModel.class, oJavarestmethodModel.getrestmethodId());

        /* Delete any collection related with the existing restmethod from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavarestmethodModel.deleteAllCollections(hibernateSession);

        /* Delete the existing restmethod from the database*/
        hibernateSession.delete(oJavarestmethodModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestmethodModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the restmethod resources from the service database
    that are related to a specific resource resource.*/

    public JavaresourceModel getrestmethodList(JavaresourceModel oJavaresourceModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the resource of which the restmethod resource list is needed*/
        oJavaresourceModel = (JavaresourceModel) hibernateSession.get(JavaresourceModel.class, oJavaresourceModel.getresourceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaresourceModel;
    }
    /* This function handles the low level JPA activities so as to add a new soapservice resource to the service database.*/
    public JavasoapserviceModel postsoapservice(JavasoapserviceModel oJavasoapserviceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new soapservice to database*/
        int soapserviceId = (Integer) hibernateSession.save(oJavasoapserviceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavasoapserviceModel with updated soapserviceId*/
        oJavasoapserviceModel.setsoapserviceId(soapserviceId);
        return oJavasoapserviceModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing soapservice resource of the service database.*/
    public JavasoapserviceModel putsoapservice(JavasoapserviceModel oJavasoapserviceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing soapservice of the database*/
        hibernateSession.update(oJavasoapserviceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapserviceModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing soapservice resource from the service database.*/
    public JavasoapserviceModel getsoapservice(JavasoapserviceModel oJavasoapserviceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing soapservice from the database*/
        oJavasoapserviceModel = (JavasoapserviceModel) hibernateSession.get(JavasoapserviceModel.class, oJavasoapserviceModel.getsoapserviceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapserviceModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing soapservice resource from the service database.*/
    public JavasoapserviceModel deletesoapservice(JavasoapserviceModel oJavasoapserviceModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing soapservice from the database*/
        oJavasoapserviceModel = (JavasoapserviceModel) hibernateSession.get(JavasoapserviceModel.class, oJavasoapserviceModel.getsoapserviceId());

        /* Delete any collection related with the existing soapservice from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavasoapserviceModel.deleteAllCollections(hibernateSession);

        /* Delete the existing soapservice from the database*/
        hibernateSession.delete(oJavasoapserviceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapserviceModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the soapservice resources from the service database
    that are related to a specific account resource.*/

    public JavaaccountModel getsoapserviceList(JavaaccountModel oJavaaccountModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the account of which the soapservice resource list is needed*/
        oJavaaccountModel = (JavaaccountModel) hibernateSession.get(JavaaccountModel.class, oJavaaccountModel.getaccountId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaaccountModel;
    }
    /* This function handles the low level JPA activities so as to add a new outputmessage resource to the service database.*/
    public JavaoutputmessageModel postoutputmessage(JavaoutputmessageModel oJavaoutputmessageModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new outputmessage to database*/
        int outputmessageId = (Integer) hibernateSession.save(oJavaoutputmessageModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavaoutputmessageModel with updated outputmessageId*/
        oJavaoutputmessageModel.setoutputmessageId(outputmessageId);
        return oJavaoutputmessageModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing outputmessage resource of the service database.*/
    public JavaoutputmessageModel putoutputmessage(JavaoutputmessageModel oJavaoutputmessageModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing outputmessage of the database*/
        hibernateSession.update(oJavaoutputmessageModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputmessageModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing outputmessage resource from the service database.*/
    public JavaoutputmessageModel getoutputmessage(JavaoutputmessageModel oJavaoutputmessageModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing outputmessage from the database*/
        oJavaoutputmessageModel = (JavaoutputmessageModel) hibernateSession.get(JavaoutputmessageModel.class, oJavaoutputmessageModel.getoutputmessageId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputmessageModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing outputmessage resource from the service database.*/
    public JavaoutputmessageModel deleteoutputmessage(JavaoutputmessageModel oJavaoutputmessageModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing outputmessage from the database*/
        oJavaoutputmessageModel = (JavaoutputmessageModel) hibernateSession.get(JavaoutputmessageModel.class, oJavaoutputmessageModel.getoutputmessageId());

        /* Delete any collection related with the existing outputmessage from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavaoutputmessageModel.deleteAllCollections(hibernateSession);

        /* Delete the existing outputmessage from the database*/
        hibernateSession.delete(oJavaoutputmessageModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputmessageModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the outputmessage resources from the service database
    that are related to a specific soapoperation resource.*/

    public JavasoapoperationModel getoutputmessageList(JavasoapoperationModel oJavasoapoperationModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the soapoperation of which the outputmessage resource list is needed*/
        oJavasoapoperationModel = (JavasoapoperationModel) hibernateSession.get(JavasoapoperationModel.class, oJavasoapoperationModel.getsoapoperationId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapoperationModel;
    }
    /* This function handles the low level JPA activities so as to add a new restparameter resource to the service database.*/
    public JavarestparameterModel postrestparameter(JavarestparameterModel oJavarestparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new restparameter to database*/
        int restparameterId = (Integer) hibernateSession.save(oJavarestparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavarestparameterModel with updated restparameterId*/
        oJavarestparameterModel.setrestparameterId(restparameterId);
        return oJavarestparameterModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing restparameter resource of the service database.*/
    public JavarestparameterModel putrestparameter(JavarestparameterModel oJavarestparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing restparameter of the database*/
        hibernateSession.update(oJavarestparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestparameterModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing restparameter resource from the service database.*/
    public JavarestparameterModel getrestparameter(JavarestparameterModel oJavarestparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing restparameter from the database*/
        oJavarestparameterModel = (JavarestparameterModel) hibernateSession.get(JavarestparameterModel.class, oJavarestparameterModel.getrestparameterId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestparameterModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing restparameter resource from the service database.*/
    public JavarestparameterModel deleterestparameter(JavarestparameterModel oJavarestparameterModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing restparameter from the database*/
        oJavarestparameterModel = (JavarestparameterModel) hibernateSession.get(JavarestparameterModel.class, oJavarestparameterModel.getrestparameterId());

        /* Delete any collection related with the existing restparameter from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavarestparameterModel.deleteAllCollections(hibernateSession);

        /* Delete the existing restparameter from the database*/
        hibernateSession.delete(oJavarestparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestparameterModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the restparameter resources from the service database
    that are related to a specific restmethod resource.*/

    public JavarestmethodModel getrestmethodrestparameterList(JavarestmethodModel oJavarestmethodModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the restmethod of which the restparameter resource list is needed*/
        oJavarestmethodModel = (JavarestmethodModel) hibernateSession.get(JavarestmethodModel.class, oJavarestmethodModel.getrestmethodId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestmethodModel;
    }
	/* This function handles the low level hibernate activities so as to retrieve all the restparameter resources from the service database
    that are related to a specific resource resource.*/

    public JavaresourceModel getresourcerestparameterList(JavaresourceModel oJavaresourceModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the resource of which the restparameter resource list is needed*/
        oJavaresourceModel = (JavaresourceModel) hibernateSession.get(JavaresourceModel.class, oJavaresourceModel.getresourceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaresourceModel;
    }
    /* This function handles the low level JPA activities so as to add a new inputparameter resource to the service database.*/
    public JavainputparameterModel postinputparameter(JavainputparameterModel oJavainputparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new inputparameter to database*/
        int inputparameterId = (Integer) hibernateSession.save(oJavainputparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavainputparameterModel with updated inputparameterId*/
        oJavainputparameterModel.setinputparameterId(inputparameterId);
        return oJavainputparameterModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing inputparameter resource of the service database.*/
    public JavainputparameterModel putinputparameter(JavainputparameterModel oJavainputparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing inputparameter of the database*/
        hibernateSession.update(oJavainputparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputparameterModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing inputparameter resource from the service database.*/
    public JavainputparameterModel getinputparameter(JavainputparameterModel oJavainputparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing inputparameter from the database*/
        oJavainputparameterModel = (JavainputparameterModel) hibernateSession.get(JavainputparameterModel.class, oJavainputparameterModel.getinputparameterId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputparameterModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing inputparameter resource from the service database.*/
    public JavainputparameterModel deleteinputparameter(JavainputparameterModel oJavainputparameterModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing inputparameter from the database*/
        oJavainputparameterModel = (JavainputparameterModel) hibernateSession.get(JavainputparameterModel.class, oJavainputparameterModel.getinputparameterId());

        /* Delete any collection related with the existing inputparameter from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavainputparameterModel.deleteAllCollections(hibernateSession);

        /* Delete the existing inputparameter from the database*/
        hibernateSession.delete(oJavainputparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputparameterModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the inputparameter resources from the service database
    that are related to a specific inputparameter resource.*/

    public JavainputparameterModel getinputparameterinputparameterList(JavainputparameterModel oJavainputparameterModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the inputparameter of which the inputparameter resource list is needed*/
        oJavainputparameterModel = (JavainputparameterModel) hibernateSession.get(JavainputparameterModel.class, oJavainputparameterModel.getinputparameterId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputparameterModel;
    }
	/* This function handles the low level hibernate activities so as to retrieve all the inputparameter resources from the service database
    that are related to a specific inputmessage resource.*/

    public JavainputmessageModel getinputmessageinputparameterList(JavainputmessageModel oJavainputmessageModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the inputmessage of which the inputparameter resource list is needed*/
        oJavainputmessageModel = (JavainputmessageModel) hibernateSession.get(JavainputmessageModel.class, oJavainputmessageModel.getinputmessageId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputmessageModel;
    }
    /* This function handles the low level JPA activities so as to add a new outputparameter resource to the service database.*/
    public JavaoutputparameterModel postoutputparameter(JavaoutputparameterModel oJavaoutputparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new outputparameter to database*/
        int outputparameterId = (Integer) hibernateSession.save(oJavaoutputparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavaoutputparameterModel with updated outputparameterId*/
        oJavaoutputparameterModel.setoutputparameterId(outputparameterId);
        return oJavaoutputparameterModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing outputparameter resource of the service database.*/
    public JavaoutputparameterModel putoutputparameter(JavaoutputparameterModel oJavaoutputparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing outputparameter of the database*/
        hibernateSession.update(oJavaoutputparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputparameterModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing outputparameter resource from the service database.*/
    public JavaoutputparameterModel getoutputparameter(JavaoutputparameterModel oJavaoutputparameterModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing outputparameter from the database*/
        oJavaoutputparameterModel = (JavaoutputparameterModel) hibernateSession.get(JavaoutputparameterModel.class, oJavaoutputparameterModel.getoutputparameterId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputparameterModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing outputparameter resource from the service database.*/
    public JavaoutputparameterModel deleteoutputparameter(JavaoutputparameterModel oJavaoutputparameterModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing outputparameter from the database*/
        oJavaoutputparameterModel = (JavaoutputparameterModel) hibernateSession.get(JavaoutputparameterModel.class, oJavaoutputparameterModel.getoutputparameterId());

        /* Delete any collection related with the existing outputparameter from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavaoutputparameterModel.deleteAllCollections(hibernateSession);

        /* Delete the existing outputparameter from the database*/
        hibernateSession.delete(oJavaoutputparameterModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputparameterModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the outputparameter resources from the service database
    that are related to a specific outputmessage resource.*/

    public JavaoutputmessageModel getoutputmessageoutputparameterList(JavaoutputmessageModel oJavaoutputmessageModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the outputmessage of which the outputparameter resource list is needed*/
        oJavaoutputmessageModel = (JavaoutputmessageModel) hibernateSession.get(JavaoutputmessageModel.class, oJavaoutputmessageModel.getoutputmessageId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputmessageModel;
    }
	/* This function handles the low level hibernate activities so as to retrieve all the outputparameter resources from the service database
    that are related to a specific outputparameter resource.*/

    public JavaoutputparameterModel getoutputparameteroutputparameterList(JavaoutputparameterModel oJavaoutputparameterModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the outputparameter of which the outputparameter resource list is needed*/
        oJavaoutputparameterModel = (JavaoutputparameterModel) hibernateSession.get(JavaoutputparameterModel.class, oJavaoutputparameterModel.getoutputparameterId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaoutputparameterModel;
    }
    /* This function handles the low level JPA activities so as to add a new inputmessage resource to the service database.*/
    public JavainputmessageModel postinputmessage(JavainputmessageModel oJavainputmessageModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new inputmessage to database*/
        int inputmessageId = (Integer) hibernateSession.save(oJavainputmessageModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavainputmessageModel with updated inputmessageId*/
        oJavainputmessageModel.setinputmessageId(inputmessageId);
        return oJavainputmessageModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing inputmessage resource of the service database.*/
    public JavainputmessageModel putinputmessage(JavainputmessageModel oJavainputmessageModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing inputmessage of the database*/
        hibernateSession.update(oJavainputmessageModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputmessageModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing inputmessage resource from the service database.*/
    public JavainputmessageModel getinputmessage(JavainputmessageModel oJavainputmessageModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing inputmessage from the database*/
        oJavainputmessageModel = (JavainputmessageModel) hibernateSession.get(JavainputmessageModel.class, oJavainputmessageModel.getinputmessageId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputmessageModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing inputmessage resource from the service database.*/
    public JavainputmessageModel deleteinputmessage(JavainputmessageModel oJavainputmessageModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing inputmessage from the database*/
        oJavainputmessageModel = (JavainputmessageModel) hibernateSession.get(JavainputmessageModel.class, oJavainputmessageModel.getinputmessageId());

        /* Delete any collection related with the existing inputmessage from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavainputmessageModel.deleteAllCollections(hibernateSession);

        /* Delete the existing inputmessage from the database*/
        hibernateSession.delete(oJavainputmessageModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavainputmessageModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the inputmessage resources from the service database
    that are related to a specific soapoperation resource.*/

    public JavasoapoperationModel getinputmessageList(JavasoapoperationModel oJavasoapoperationModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the soapoperation of which the inputmessage resource list is needed*/
        oJavasoapoperationModel = (JavasoapoperationModel) hibernateSession.get(JavasoapoperationModel.class, oJavasoapoperationModel.getsoapoperationId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapoperationModel;
    }
    /* This function handles the low level JPA activities so as to add a new resource resource to the service database.*/
    public JavaresourceModel postresource(JavaresourceModel oJavaresourceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new resource to database*/
        int resourceId = (Integer) hibernateSession.save(oJavaresourceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavaresourceModel with updated resourceId*/
        oJavaresourceModel.setresourceId(resourceId);
        return oJavaresourceModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing resource resource of the service database.*/
    public JavaresourceModel putresource(JavaresourceModel oJavaresourceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing resource of the database*/
        hibernateSession.update(oJavaresourceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaresourceModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing resource resource from the service database.*/
    public JavaresourceModel getresource(JavaresourceModel oJavaresourceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing resource from the database*/
        oJavaresourceModel = (JavaresourceModel) hibernateSession.get(JavaresourceModel.class, oJavaresourceModel.getresourceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaresourceModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing resource resource from the service database.*/
    public JavaresourceModel deleteresource(JavaresourceModel oJavaresourceModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing resource from the database*/
        oJavaresourceModel = (JavaresourceModel) hibernateSession.get(JavaresourceModel.class, oJavaresourceModel.getresourceId());

        /* Delete any collection related with the existing resource from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavaresourceModel.deleteAllCollections(hibernateSession);

        /* Delete the existing resource from the database*/
        hibernateSession.delete(oJavaresourceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaresourceModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the resource resources from the service database
    that are related to a specific restservice resource.*/

    public JavarestserviceModel getresourceList(JavarestserviceModel oJavarestserviceModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the restservice of which the resource resource list is needed*/
        oJavarestserviceModel = (JavarestserviceModel) hibernateSession.get(JavarestserviceModel.class, oJavarestserviceModel.getrestserviceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestserviceModel;
    }
    /* This function handles the low level JPA activities so as to add a new account resource to the service database.*/
    public JavaaccountModel postaccount(JavaaccountModel oJavaaccountModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new account to database*/
        int accountId = (Integer) hibernateSession.save(oJavaaccountModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavaaccountModel with updated accountId*/
        oJavaaccountModel.setaccountId(accountId);
        return oJavaaccountModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing account resource of the service database.*/
    public JavaaccountModel putaccount(JavaaccountModel oJavaaccountModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing account of the database*/
        hibernateSession.update(oJavaaccountModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaaccountModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing account resource from the service database.*/
    public JavaaccountModel getaccount(JavaaccountModel oJavaaccountModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing account from the database*/
        oJavaaccountModel = (JavaaccountModel) hibernateSession.get(JavaaccountModel.class, oJavaaccountModel.getaccountId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaaccountModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing account resource from the service database.*/
    public JavaaccountModel deleteaccount(JavaaccountModel oJavaaccountModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing account from the database*/
        oJavaaccountModel = (JavaaccountModel) hibernateSession.get(JavaaccountModel.class, oJavaaccountModel.getaccountId());

        /* Delete any collection related with the existing account from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavaaccountModel.deleteAllCollections(hibernateSession);

        /* Delete the existing account from the database*/
        hibernateSession.delete(oJavaaccountModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaaccountModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve all the account resources from the service database.*/

    public Set<JavaaccountModel> getaccountList(Set<JavaaccountModel> SetOfaccountList){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the list of account resources that are needed.*/
        String strHibernateQuery = "FROM JavaaccountModel";
        Query hibernateQuery = hibernateSession.createQuery(strHibernateQuery);
        SetOfaccountList = new HashSet(hibernateQuery.list());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return SetOfaccountList;
    }
    /* This function handles the low level JPA activities so as to add a new soapoperation resource to the service database.*/
    public JavasoapoperationModel postsoapoperation(JavasoapoperationModel oJavasoapoperationModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new soapoperation to database*/
        int soapoperationId = (Integer) hibernateSession.save(oJavasoapoperationModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavasoapoperationModel with updated soapoperationId*/
        oJavasoapoperationModel.setsoapoperationId(soapoperationId);
        return oJavasoapoperationModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing soapoperation resource of the service database.*/
    public JavasoapoperationModel putsoapoperation(JavasoapoperationModel oJavasoapoperationModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing soapoperation of the database*/
        hibernateSession.update(oJavasoapoperationModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapoperationModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing soapoperation resource from the service database.*/
    public JavasoapoperationModel getsoapoperation(JavasoapoperationModel oJavasoapoperationModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing soapoperation from the database*/
        oJavasoapoperationModel = (JavasoapoperationModel) hibernateSession.get(JavasoapoperationModel.class, oJavasoapoperationModel.getsoapoperationId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapoperationModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing soapoperation resource from the service database.*/
    public JavasoapoperationModel deletesoapoperation(JavasoapoperationModel oJavasoapoperationModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing soapoperation from the database*/
        oJavasoapoperationModel = (JavasoapoperationModel) hibernateSession.get(JavasoapoperationModel.class, oJavasoapoperationModel.getsoapoperationId());

        /* Delete any collection related with the existing soapoperation from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavasoapoperationModel.deleteAllCollections(hibernateSession);

        /* Delete the existing soapoperation from the database*/
        hibernateSession.delete(oJavasoapoperationModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapoperationModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the soapoperation resources from the service database
    that are related to a specific soapservice resource.*/

    public JavasoapserviceModel getsoapoperationList(JavasoapserviceModel oJavasoapserviceModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the soapservice of which the soapoperation resource list is needed*/
        oJavasoapserviceModel = (JavasoapserviceModel) hibernateSession.get(JavasoapserviceModel.class, oJavasoapserviceModel.getsoapserviceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavasoapserviceModel;
    }
    /* This function handles the low level JPA activities so as to add a new restservice resource to the service database.*/
    public JavarestserviceModel postrestservice(JavarestserviceModel oJavarestserviceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Insert the new restservice to database*/
        int restserviceId = (Integer) hibernateSession.save(oJavarestserviceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();

        /* Return the JavarestserviceModel with updated restserviceId*/
        oJavarestserviceModel.setrestserviceId(restserviceId);
        return oJavarestserviceModel;
    }
	
    /* This function handles the low level hibernate activities so as to update an existing restservice resource of the service database.*/
    public JavarestserviceModel putrestservice(JavarestserviceModel oJavarestserviceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Update the existing restservice of the database*/
        hibernateSession.update(oJavarestserviceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestserviceModel;
    }

    /* This function handles the low level hibernate activities so as to retrieve an existing restservice resource from the service database.*/
    public JavarestserviceModel getrestservice(JavarestserviceModel oJavarestserviceModel){

    	/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing restservice from the database*/
        oJavarestserviceModel = (JavarestserviceModel) hibernateSession.get(JavarestserviceModel.class, oJavarestserviceModel.getrestserviceId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestserviceModel;
    }

    /* This function handles the low level hibernate activities so as to delete an existing restservice resource from the service database.*/
    public JavarestserviceModel deleterestservice(JavarestserviceModel oJavarestserviceModel){

   		/* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Retrieve the existing restservice from the database*/
        oJavarestserviceModel = (JavarestserviceModel) hibernateSession.get(JavarestserviceModel.class, oJavarestserviceModel.getrestserviceId());

        /* Delete any collection related with the existing restservice from the database.
        Note: this is needed because some hibernate versions do not handle correctly cascade delete on collections.*/
        oJavarestserviceModel.deleteAllCollections(hibernateSession);

        /* Delete the existing restservice from the database*/
        hibernateSession.delete(oJavarestserviceModel);

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavarestserviceModel;
    }

	/* This function handles the low level hibernate activities so as to retrieve all the restservice resources from the service database
    that are related to a specific account resource.*/

    public JavaaccountModel getrestserviceList(JavaaccountModel oJavaaccountModel){

        /* Create a new hibernate session and begin the transaction*/
        Session hibernateSession = HibernateUtil.getSessionFactory().openSession();
        Transaction hibernateTransaction = hibernateSession.beginTransaction();

        /* Find the account of which the restservice resource list is needed*/
        oJavaaccountModel = (JavaaccountModel) hibernateSession.get(JavaaccountModel.class, oJavaaccountModel.getaccountId());

        /* Commit and terminate the session*/
        hibernateTransaction.commit();
        hibernateSession.close();
        return oJavaaccountModel;
    }
}
