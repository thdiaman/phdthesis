/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.inputparameter;


import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterModel;

/* This class processes POST requests for inputparameter resources and creates the hypermedia to be returned to the client*/

public class PostinputparameterinputparameterHandler{


    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavainputparameterModel oJavainputparameterModel;
    private JavainputparameterModel oSourceJavainputparameterModel;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public PostinputparameterinputparameterHandler(String authHeader, int SourceinputparameterId, JavainputparameterModel oJavainputparameterModel, UriInfo oApplicationUri){
        this.oJavainputparameterModel = oJavainputparameterModel;
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
        oSourceJavainputparameterModel = new JavainputparameterModel();
        oSourceJavainputparameterModel.setinputparameterId(SourceinputparameterId);
        oJavainputparameterModel.setinputparameter(this.oSourceJavainputparameterModel);
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
    }

    public JavainputparameterModel postJavainputparameterModel(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

        return createHypermedia(oHibernateController.postinputparameter(oJavainputparameterModel));
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client so as it will be able to forward the application state in a valid way.*/
    public JavainputparameterModel createHypermedia(JavainputparameterModel oJavainputparameterModel){

        /* Create hypermedia links towards this specific inputparameter resource. These must be GET and POST as it is prescribed in the meta-models.*/
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Get all inputparameters of this inputparameter", "GET", "Sibling"));
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Create a new inputparameter", "POST", "Sibling"));

        /* Then calculate the relative path to any resources that are related of this one and add the according hypermedia links to the Linklist.*/
        String oRelativePath;
        oRelativePath = oApplicationUri.getPath().replaceAll("multiinputparameterManager/", "multiinputparameter/");
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavainputparameterModel.getinputparameterId()), oJavainputparameterModel.getname(), "GET", "Child", oJavainputparameterModel.getinputparameterId()));
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavainputparameterModel.getinputparameterId()), oJavainputparameterModel.getname(), "PUT", "Child", oJavainputparameterModel.getinputparameterId()));
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavainputparameterModel.getinputparameterId()), oJavainputparameterModel.getname(), "DELETE", "Child", oJavainputparameterModel.getinputparameterId()));

        /* Finally, calculate the relative path towards the resources of which this one is related.
        Then add hypermedia links for each one of them*/
        this.oSourceJavainputparameterModel = HibernateController.getHibernateControllerHandle().getinputparameter(this.oSourceJavainputparameterModel);
		if(this.oSourceJavainputparameterModel.getinputparameter() != null){
            oRelativePath = String.format("multiinputparameter/inputparameter/%d/%s", this.oSourceJavainputparameterModel.getinputparameter().getinputparameterId(), oApplicationUri.getPath().replaceAll("multiinputparameterManager/", ""));
		}

        else		if(this.oSourceJavainputparameterModel.getinputmessage() != null){
            oRelativePath = String.format("multiinputparameter/inputmessage/%d/%s", this.oSourceJavainputparameterModel.getinputmessage().getinputmessageId(), oApplicationUri.getPath().replaceAll("multiinputparameterManager/", ""));
		}
        int iLastSlashIndex = String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).lastIndexOf("/");
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Delete the parent inputparameter", "DELETE", "Parent"));
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Get the parent inputparameter", "GET", "Parent"));
        oJavainputparameterModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Update the inputparameter", "PUT", "Parent"));
        return oJavainputparameterModel;
    }
}
