/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.outputparameter;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.DefaultValue;


/* This class defines the web API of the individual outputparameter resource. It may handle PUT, GET and/or DELETE requests 
   depending on the specific CIM of the service.*/

@Path("/multioutputparameter")
public class JavaoutputparameterController{

    @Context
    private UriInfo oApplicationUri;

	/* This function handles http GET requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/outputmessage/{outputmessageId}/outputparameter/{outputparameterId}")
	@GET
	@Produces("application/JSON")
    public JavaoutputparameterModel getoutputmessageoutputparameter(@HeaderParam("authorization") String authHeader, @PathParam("outputparameterId") int outputparameterId){
        GetoutputmessageoutputparameterHandler oGetoutputmessageoutputparameterHandler = new GetoutputmessageoutputparameterHandler(authHeader, outputparameterId, oApplicationUri);
        return oGetoutputmessageoutputparameterHandler.getJavaoutputparameterModel();
    }

	/* This function handles http GET requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/outputparameter/{outputparameterId}/outputparameter/{targetoutputparameterId}")
	@GET
	@Produces("application/JSON")
    public JavaoutputparameterModel getoutputparameteroutputparameter(@HeaderParam("authorization") String authHeader, @PathParam("targetoutputparameterId") int targetoutputparameterId){
        GetoutputparameteroutputparameterHandler oGetoutputparameteroutputparameterHandler = new GetoutputparameteroutputparameterHandler(authHeader, targetoutputparameterId, oApplicationUri);
        return oGetoutputparameteroutputparameterHandler.getJavaoutputparameterModel();
    }

	/* This function handles http PUT requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/outputmessage/{outputmessageId}/outputparameter/{outputparameterId}")
	@PUT
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavaoutputparameterModel putoutputmessageoutputparameter(@HeaderParam("authorization") String authHeader, @PathParam("outputmessageId") int outputmessageId, @PathParam("outputparameterId") int outputparameterId,  JavaoutputparameterModel oJavaoutputparameterModel){
        PutoutputmessageoutputparameterHandler oPutoutputmessageoutputparameterHandler = new PutoutputmessageoutputparameterHandler(authHeader, outputmessageId, outputparameterId, oJavaoutputparameterModel, oApplicationUri);
        return oPutoutputmessageoutputparameterHandler.putJavaoutputparameterModel();
    }

	/* This function handles http PUT requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/outputparameter/{outputparameterId}/outputparameter/{targetoutputparameterId}")
	@PUT
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavaoutputparameterModel putoutputparameteroutputparameter(@HeaderParam("authorization") String authHeader, @PathParam("outputparameterId") int outputparameterId, @PathParam("targetoutputparameterId") int targetoutputparameterId,  JavaoutputparameterModel oJavaoutputparameterModel){
        PutoutputparameteroutputparameterHandler oPutoutputparameteroutputparameterHandler = new PutoutputparameteroutputparameterHandler(authHeader, outputparameterId, targetoutputparameterId, oJavaoutputparameterModel, oApplicationUri);
        return oPutoutputparameteroutputparameterHandler.putJavaoutputparameterModel();
    }

    /* This function handles http DELETE requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/outputmessage/{outputmessageId}/outputparameter/{outputparameterId}")
	@DELETE
	@Produces("application/JSON")
    public JavaoutputparameterModel deleteoutputmessageoutputparameter(@HeaderParam("authorization") String authHeader, @PathParam("outputparameterId") int outputparameterId){
        DeleteoutputmessageoutputparameterHandler oDeleteoutputmessageoutputparameterHandler = new DeleteoutputmessageoutputparameterHandler(authHeader, outputparameterId, oApplicationUri);
        return oDeleteoutputmessageoutputparameterHandler.deleteJavaoutputparameterModel();
    }

    /* This function handles http DELETE requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/outputparameter/{outputparameterId}/outputparameter/{targetoutputparameterId}")
	@DELETE
	@Produces("application/JSON")
    public JavaoutputparameterModel deleteoutputparameteroutputparameter(@HeaderParam("authorization") String authHeader, @PathParam("targetoutputparameterId") int targetoutputparameterId){
        DeleteoutputparameteroutputparameterHandler oDeleteoutputparameteroutputparameterHandler = new DeleteoutputparameteroutputparameterHandler(authHeader, targetoutputparameterId, oApplicationUri);
        return oDeleteoutputparameteroutputparameterHandler.deleteJavaoutputparameterModel();
    }
}

