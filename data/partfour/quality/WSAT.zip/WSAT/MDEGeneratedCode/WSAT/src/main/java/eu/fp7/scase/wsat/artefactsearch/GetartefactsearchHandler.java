/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.artefactsearch;

import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;

import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.utilities.PersistenceUtil;
import eu.fp7.scase.wsat.restmethod.JavarestmethodModel;
import eu.fp7.scase.wsat.soapservice.JavasoapserviceModel;
import eu.fp7.scase.wsat.restparameter.JavarestparameterModel;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterModel;
import eu.fp7.scase.wsat.outputparameter.JavaoutputparameterModel;
import eu.fp7.scase.wsat.resource.JavaresourceModel;
import eu.fp7.scase.wsat.soapoperation.JavasoapoperationModel;

import org.hibernate.search.jpa.FullTextEntityManager;
import org.hibernate.search.jpa.Search;
import org.hibernate.search.query.dsl.QueryBuilder;

/* This class processes search requests for artefactsearch resource and creates the hypermedia links with the search results to be returned to the client*/
public class GetartefactsearchHandler{

    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavaAlgoartefactsearchModel oJavaAlgoartefactsearchModel;
	private String searchRestmethodMethoddescription;
	private String searchRestmethodMethodidentifier;
	private String searchRestmethodMethodkeywords;
	private String searchSoapserviceDescription;
	private String searchSoapserviceKeywords;
	private String searchRestparameterParameterdescription;
	private String searchInputparameterKeywords;
	private String searchOutputparameterKeywords;
	private String searchResourceResourcedescription;
	private String searchResourceResourcekeywords;
	private String searchSoapoperationDescription;
	private String searchSoapoperationKeywords;
	private String searchKeyword;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public GetartefactsearchHandler(String authHeader, String searchKeyword, String searchRestmethodMethoddescription, String searchRestmethodMethodidentifier, String searchRestmethodMethodkeywords, String searchSoapserviceDescription, String searchSoapserviceKeywords, String searchRestparameterParameterdescription, String searchInputparameterKeywords, String searchOutputparameterKeywords, String searchResourceResourcedescription, String searchResourceResourcekeywords, String searchSoapoperationDescription, String searchSoapoperationKeywords, UriInfo oApplicationUri){
        oJavaAlgoartefactsearchModel = new JavaAlgoartefactsearchModel();
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
		this.searchRestmethodMethoddescription = searchRestmethodMethoddescription;
		this.searchRestmethodMethodidentifier = searchRestmethodMethodidentifier;
		this.searchRestmethodMethodkeywords = searchRestmethodMethodkeywords;
		this.searchSoapserviceDescription = searchSoapserviceDescription;
		this.searchSoapserviceKeywords = searchSoapserviceKeywords;
		this.searchRestparameterParameterdescription = searchRestparameterParameterdescription;
		this.searchInputparameterKeywords = searchInputparameterKeywords;
		this.searchOutputparameterKeywords = searchOutputparameterKeywords;
		this.searchResourceResourcedescription = searchResourceResourcedescription;
		this.searchResourceResourcekeywords = searchResourceResourcekeywords;
		this.searchSoapoperationDescription = searchSoapoperationDescription;
		this.searchSoapoperationKeywords = searchSoapoperationKeywords;
		this.searchKeyword = searchKeyword;
    }

    public JavaAlgoartefactsearchModel getartefactsearch(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

		//Return any results in the hypermedia links form.
        return searchDatabase();
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client that include all the search results, so as it will be able to forward the application state in a valid way.*/
    public JavaAlgoartefactsearchModel searchDatabase(){
		
		// if any searchable property of resource Restmethod is included in clients search request
    	if((this.searchRestmethodMethoddescription != null && this.searchRestmethodMethoddescription.equalsIgnoreCase("true")) || (this.searchRestmethodMethodidentifier != null && this.searchRestmethodMethodidentifier.equalsIgnoreCase("true")) || (this.searchRestmethodMethodkeywords != null && this.searchRestmethodMethodkeywords.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addRestmethodHypermediaLinks();
    	}
		// if any searchable property of resource Soapservice is included in clients search request
    	if((this.searchSoapserviceDescription != null && this.searchSoapserviceDescription.equalsIgnoreCase("true")) || (this.searchSoapserviceKeywords != null && this.searchSoapserviceKeywords.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addSoapserviceHypermediaLinks();
    	}
		// if any searchable property of resource Restparameter is included in clients search request
    	if((this.searchRestparameterParameterdescription != null && this.searchRestparameterParameterdescription.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addRestparameterHypermediaLinks();
    	}
		// if any searchable property of resource Inputparameter is included in clients search request
    	if((this.searchInputparameterKeywords != null && this.searchInputparameterKeywords.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addInputparameterHypermediaLinks();
    	}
		// if any searchable property of resource Outputparameter is included in clients search request
    	if((this.searchOutputparameterKeywords != null && this.searchOutputparameterKeywords.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addOutputparameterHypermediaLinks();
    	}
		// if any searchable property of resource Resource is included in clients search request
    	if((this.searchResourceResourcedescription != null && this.searchResourceResourcedescription.equalsIgnoreCase("true")) || (this.searchResourceResourcekeywords != null && this.searchResourceResourcekeywords.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addResourceHypermediaLinks();
    	}
		// if any searchable property of resource Soapoperation is included in clients search request
    	if((this.searchSoapoperationDescription != null && this.searchSoapoperationDescription.equalsIgnoreCase("true")) || (this.searchSoapoperationKeywords != null && this.searchSoapoperationKeywords.equalsIgnoreCase("true")))
    	{
			//then add hypermedia links to any search results from this resource
    		addSoapoperationHypermediaLinks();
    	}

		return this.oJavaAlgoartefactsearchModel;
	}

	/* This functions produces hypermedia links to be sent to the client that include search results of resource Restmethod search requests
	 */
    public void addRestmethodHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchRestmethodMethoddescription != null && this.searchRestmethodMethoddescription.equalsIgnoreCase("true"))){
			strQueryParams.add("methoddescription");
		}

		if((this.searchRestmethodMethodidentifier != null && this.searchRestmethodMethodidentifier.equalsIgnoreCase("true"))){
			strQueryParams.add("methodidentifier");
		}

		if((this.searchRestmethodMethodkeywords != null && this.searchRestmethodMethodkeywords.equalsIgnoreCase("true"))){
			strQueryParams.add("methodkeywords");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavarestmethodModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavarestmethodModel.class);

    	// execute search
    	List<JavarestmethodModel> JavarestmethodModelList =(List<JavarestmethodModel>) oJpaQuery.getResultList();

    	Iterator<JavarestmethodModel> iteratorOfJavarestmethodModelList = JavarestmethodModelList.iterator();
    	while(iteratorOfJavarestmethodModelList.hasNext())
    	{
    		JavarestmethodModel oJavarestmethodModel = iteratorOfJavarestmethodModelList.next();
    		oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d/%s/%d", oApplicationUri.getBaseUri(), "resource", oJavarestmethodModel.getresource().getresourceId(), "restmethod", oJavarestmethodModel.getrestmethodId()), "Search result", "GET", "restmethod"));
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	/* This functions produces hypermedia links to be sent to the client that include search results of resource Soapservice search requests
	 */
    public void addSoapserviceHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchSoapserviceDescription != null && this.searchSoapserviceDescription.equalsIgnoreCase("true"))){
			strQueryParams.add("description");
		}

		if((this.searchSoapserviceKeywords != null && this.searchSoapserviceKeywords.equalsIgnoreCase("true"))){
			strQueryParams.add("keywords");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavasoapserviceModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavasoapserviceModel.class);

    	// execute search
    	List<JavasoapserviceModel> JavasoapserviceModelList =(List<JavasoapserviceModel>) oJpaQuery.getResultList();

    	Iterator<JavasoapserviceModel> iteratorOfJavasoapserviceModelList = JavasoapserviceModelList.iterator();
    	while(iteratorOfJavasoapserviceModelList.hasNext())
    	{
    		JavasoapserviceModel oJavasoapserviceModel = iteratorOfJavasoapserviceModelList.next();
    		oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d/%s/%d", oApplicationUri.getBaseUri(), "account", oJavasoapserviceModel.getaccount().getaccountId(), "soapservice", oJavasoapserviceModel.getsoapserviceId()), "Search result", "GET", "soapservice"));
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	/* This functions produces hypermedia links to be sent to the client that include search results of resource Restparameter search requests
	 */
    public void addRestparameterHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchRestparameterParameterdescription != null && this.searchRestparameterParameterdescription.equalsIgnoreCase("true"))){
			strQueryParams.add("parameterdescription");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavarestparameterModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavarestparameterModel.class);

    	// execute search
    	List<JavarestparameterModel> JavarestparameterModelList =(List<JavarestparameterModel>) oJpaQuery.getResultList();

    	Iterator<JavarestparameterModel> iteratorOfJavarestparameterModelList = JavarestparameterModelList.iterator();
    	while(iteratorOfJavarestparameterModelList.hasNext())
    	{
    		JavarestparameterModel oJavarestparameterModel = iteratorOfJavarestparameterModelList.next();
			if(oJavarestparameterModel.getrestmethod() != null){
				oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%smultirestparameter/%s/%d/%s/%d", oApplicationUri.getBaseUri(), "restmethod", oJavarestparameterModel.getrestmethod().getrestmethodId(), "restparameter", oJavarestparameterModel.getrestparameterId()), "Search result", "GET", "restparameter"));
			}
			if(oJavarestparameterModel.getresource() != null){
				oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%smultirestparameter/%s/%d/%s/%d", oApplicationUri.getBaseUri(), "resource", oJavarestparameterModel.getresource().getresourceId(), "restparameter", oJavarestparameterModel.getrestparameterId()), "Search result", "GET", "restparameter"));
			}
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	/* This functions produces hypermedia links to be sent to the client that include search results of resource Inputparameter search requests
	 */
    public void addInputparameterHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchInputparameterKeywords != null && this.searchInputparameterKeywords.equalsIgnoreCase("true"))){
			strQueryParams.add("keywords");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavainputparameterModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavainputparameterModel.class);

    	// execute search
    	List<JavainputparameterModel> JavainputparameterModelList =(List<JavainputparameterModel>) oJpaQuery.getResultList();

    	Iterator<JavainputparameterModel> iteratorOfJavainputparameterModelList = JavainputparameterModelList.iterator();
    	while(iteratorOfJavainputparameterModelList.hasNext())
    	{
    		JavainputparameterModel oJavainputparameterModel = iteratorOfJavainputparameterModelList.next();
			if(oJavainputparameterModel.getinputparameter() != null){
				oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%smultiinputparameter/%s/%d/%s/%d", oApplicationUri.getBaseUri(), "inputparameter", oJavainputparameterModel.getinputparameter().getinputparameterId(), "inputparameter", oJavainputparameterModel.getinputparameterId()), "Search result", "GET", "inputparameter"));
			}
			if(oJavainputparameterModel.getinputmessage() != null){
				oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%smultiinputparameter/%s/%d/%s/%d", oApplicationUri.getBaseUri(), "inputmessage", oJavainputparameterModel.getinputmessage().getinputmessageId(), "inputparameter", oJavainputparameterModel.getinputparameterId()), "Search result", "GET", "inputparameter"));
			}
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	/* This functions produces hypermedia links to be sent to the client that include search results of resource Outputparameter search requests
	 */
    public void addOutputparameterHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchOutputparameterKeywords != null && this.searchOutputparameterKeywords.equalsIgnoreCase("true"))){
			strQueryParams.add("keywords");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavaoutputparameterModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavaoutputparameterModel.class);

    	// execute search
    	List<JavaoutputparameterModel> JavaoutputparameterModelList =(List<JavaoutputparameterModel>) oJpaQuery.getResultList();

    	Iterator<JavaoutputparameterModel> iteratorOfJavaoutputparameterModelList = JavaoutputparameterModelList.iterator();
    	while(iteratorOfJavaoutputparameterModelList.hasNext())
    	{
    		JavaoutputparameterModel oJavaoutputparameterModel = iteratorOfJavaoutputparameterModelList.next();
			if(oJavaoutputparameterModel.getoutputmessage() != null){
				oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%smultioutputparameter/%s/%d/%s/%d", oApplicationUri.getBaseUri(), "outputmessage", oJavaoutputparameterModel.getoutputmessage().getoutputmessageId(), "outputparameter", oJavaoutputparameterModel.getoutputparameterId()), "Search result", "GET", "outputparameter"));
			}
			if(oJavaoutputparameterModel.getoutputparameter() != null){
				oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%smultioutputparameter/%s/%d/%s/%d", oApplicationUri.getBaseUri(), "outputparameter", oJavaoutputparameterModel.getoutputparameter().getoutputparameterId(), "outputparameter", oJavaoutputparameterModel.getoutputparameterId()), "Search result", "GET", "outputparameter"));
			}
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	/* This functions produces hypermedia links to be sent to the client that include search results of resource Resource search requests
	 */
    public void addResourceHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchResourceResourcedescription != null && this.searchResourceResourcedescription.equalsIgnoreCase("true"))){
			strQueryParams.add("resourcedescription");
		}

		if((this.searchResourceResourcekeywords != null && this.searchResourceResourcekeywords.equalsIgnoreCase("true"))){
			strQueryParams.add("resourcekeywords");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavaresourceModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavaresourceModel.class);

    	// execute search
    	List<JavaresourceModel> JavaresourceModelList =(List<JavaresourceModel>) oJpaQuery.getResultList();

    	Iterator<JavaresourceModel> iteratorOfJavaresourceModelList = JavaresourceModelList.iterator();
    	while(iteratorOfJavaresourceModelList.hasNext())
    	{
    		JavaresourceModel oJavaresourceModel = iteratorOfJavaresourceModelList.next();
    		oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d/%s/%d", oApplicationUri.getBaseUri(), "restservice", oJavaresourceModel.getrestservice().getrestserviceId(), "resource", oJavaresourceModel.getresourceId()), "Search result", "GET", "resource"));
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	/* This functions produces hypermedia links to be sent to the client that include search results of resource Soapoperation search requests
	 */
    public void addSoapoperationHypermediaLinks(){
   
    	FullTextEntityManager oFullTextEntityManager = PersistenceUtil.getFullTextEntityManager();
    	PersistenceUtil.beginEntityManagerTransaction();

		ArrayList<String> strQueryParams = new ArrayList<String>();		

		if((this.searchSoapoperationDescription != null && this.searchSoapoperationDescription.equalsIgnoreCase("true"))){
			strQueryParams.add("description");
		}

		if((this.searchSoapoperationKeywords != null && this.searchSoapoperationKeywords.equalsIgnoreCase("true"))){
			strQueryParams.add("keywords");
		}

    	QueryBuilder oQueryBuilder = oFullTextEntityManager.getSearchFactory().buildQueryBuilder().forEntity(JavasoapoperationModel.class).get();
    	org.apache.lucene.search.Query oLuceneQuery = oQueryBuilder.keyword().onFields(strQueryParams.toArray(new String[strQueryParams.size()])).matching(this.searchKeyword).createQuery();
    	// wrap Lucene query in a javax.persistence.Query
    	javax.persistence.Query oJpaQuery = oFullTextEntityManager.createFullTextQuery(oLuceneQuery, JavasoapoperationModel.class);

    	// execute search
    	List<JavasoapoperationModel> JavasoapoperationModelList =(List<JavasoapoperationModel>) oJpaQuery.getResultList();

    	Iterator<JavasoapoperationModel> iteratorOfJavasoapoperationModelList = JavasoapoperationModelList.iterator();
    	while(iteratorOfJavasoapoperationModelList.hasNext())
    	{
    		JavasoapoperationModel oJavasoapoperationModel = iteratorOfJavasoapoperationModelList.next();
    		oJavaAlgoartefactsearchModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d/%s/%d", oApplicationUri.getBaseUri(), "soapservice", oJavasoapoperationModel.getsoapservice().getsoapserviceId(), "soapoperation", oJavasoapoperationModel.getsoapoperationId()), "Search result", "GET", "soapoperation"));
    	}
    	
    	PersistenceUtil.endEntityManagerTransaction();    	
    }	
	
}
