/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.inputparameter;


import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.DefaultValue;


/* This class defines the web API of the manager inputparameter resource. It handles POST and GET HTTP requests, as it is prescribed by the meta-models.*/
@Path("/multiinputparameterManager")
public class JavainputparameterControllerManager{

    @Context
    private UriInfo oApplicationUri;

	/* This function handles POST requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputparameter/{inputparameterId}/inputparameter/")
	@POST
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavainputparameterModel postinputparameterinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("inputparameterId")int inputparameterId, JavainputparameterModel oJavainputparameterModel){
        PostinputparameterinputparameterHandler oPostinputparameterinputparameterHandler = new PostinputparameterinputparameterHandler(authHeader, inputparameterId, oJavainputparameterModel, oApplicationUri);
        return oPostinputparameterinputparameterHandler.postJavainputparameterModel();
    }

	/* This function handles POST requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputmessage/{inputmessageId}/inputparameter/")
	@POST
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavainputparameterModel postinputmessageinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("inputmessageId")int inputmessageId, JavainputparameterModel oJavainputparameterModel){
        PostinputmessageinputparameterHandler oPostinputmessageinputparameterHandler = new PostinputmessageinputparameterHandler(authHeader, inputmessageId, oJavainputparameterModel, oApplicationUri);
        return oPostinputmessageinputparameterHandler.postJavainputparameterModel();
    }

    /* This function handles GET requests  
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputparameter/{inputparameterId}/inputparameter/")
	@GET
	@Produces("application/JSON")
    public JavainputparameterModelManager getinputparameterinputparameterList(@HeaderParam("authorization") String authHeader, @PathParam("inputparameterId")int inputparameterId){
        GetinputparameterinputparameterListHandler oGetinputparameterinputparameterListHandler = new GetinputparameterinputparameterListHandler(authHeader, inputparameterId, oApplicationUri);
        return oGetinputparameterinputparameterListHandler.getJavainputparameterModelManager();
    }

    /* This function handles GET requests  
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputmessage/{inputmessageId}/inputparameter/")
	@GET
	@Produces("application/JSON")
    public JavainputparameterModelManager getinputmessageinputparameterList(@HeaderParam("authorization") String authHeader, @PathParam("inputmessageId")int inputmessageId){
        GetinputmessageinputparameterListHandler oGetinputmessageinputparameterListHandler = new GetinputmessageinputparameterListHandler(authHeader, inputmessageId, oApplicationUri);
        return oGetinputmessageinputparameterListHandler.getJavainputparameterModelManager();
    }

}
