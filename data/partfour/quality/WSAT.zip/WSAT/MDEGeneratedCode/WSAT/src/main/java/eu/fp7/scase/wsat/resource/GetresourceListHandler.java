/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.resource;


import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import java.util.Iterator;
import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.restservice.JavarestserviceModel;

/* This class processes GET requests for resource resources and creates the hypermedia to be returned to the client*/
public class GetresourceListHandler{

    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavarestserviceModel oJavarestserviceModel;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public GetresourceListHandler(String authHeader, int restserviceId, UriInfo oApplicationUri){
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
        oJavarestserviceModel = new JavarestserviceModel();
        oJavarestserviceModel.setrestserviceId(restserviceId);
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
    }

    public JavaresourceModelManager getJavaresourceModelManager(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

        oJavarestserviceModel = oHibernateController.getresourceList(oJavarestserviceModel);
        return createHypermedia(oJavarestserviceModel);
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client so as it will be able to forward the application state in a valid way.*/
    public JavaresourceModelManager createHypermedia(JavarestserviceModel oJavarestserviceModel){
        JavaresourceModelManager oJavaresourceModelManager = new JavaresourceModelManager();

        /* Create hypermedia links towards this specific resource resource. These must be GET and POST as it is prescribed in the meta-models.*/
        oJavaresourceModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Get all resources of this restservice", "GET", "Sibling"));
        oJavaresourceModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Create a new resource", "POST", "Sibling"));

        /* Then calculate the relative path to any related resource of this one and add for each one a hypermedia link to the Linklist.*/
        String oRelativePath;
        oRelativePath = oApplicationUri.getPath();
        Iterator<JavaresourceModel> setIterator = oJavarestserviceModel.getSetOfJavaresourceModel().iterator();
        while(setIterator.hasNext()){
            JavaresourceModel oNextJavaresourceModel = new JavaresourceModel();
            oNextJavaresourceModel = setIterator.next();
            oJavaresourceModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oNextJavaresourceModel.getresourceId()), String.format("%s", oNextJavaresourceModel.getrelativeuri()), "GET", "Child", oNextJavaresourceModel.getresourceId()));
        }

        /* Finally calculate the relative path towards the resources of which this one is related and add one hypermedia link for each one of them in the Linklist.*/
        this.oJavarestserviceModel = HibernateController.getHibernateControllerHandle().getrestservice(this.oJavarestserviceModel);
        oRelativePath = String.format("account/%d/%s", this.oJavarestserviceModel.getaccount().getaccountId(), oApplicationUri.getPath());
        int iLastSlashIndex = String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).lastIndexOf("/");
        oJavaresourceModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Delete the parent JavarestserviceModel", "DELETE", "Parent"));
        oJavaresourceModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Get the parent JavarestserviceModel", "GET", "Parent"));
        oJavaresourceModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Update the JavarestserviceModel", "PUT", "Parent"));
        return oJavaresourceModelManager;
    }
}
