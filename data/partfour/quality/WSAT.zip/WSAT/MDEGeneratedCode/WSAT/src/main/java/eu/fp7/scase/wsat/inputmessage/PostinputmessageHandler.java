/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.inputmessage;


import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.soapoperation.JavasoapoperationModel;

/* This class processes POST requests for inputmessage resources and creates the hypermedia to be returned to the client*/

public class PostinputmessageHandler{


    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavainputmessageModel oJavainputmessageModel;
    private JavasoapoperationModel oJavasoapoperationModel;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public PostinputmessageHandler(String authHeader, int soapoperationId, JavainputmessageModel oJavainputmessageModel, UriInfo oApplicationUri){
        this.oJavainputmessageModel = oJavainputmessageModel;
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
        oJavasoapoperationModel = new JavasoapoperationModel();
        oJavasoapoperationModel.setsoapoperationId(soapoperationId);
        oJavainputmessageModel.setsoapoperation(this.oJavasoapoperationModel);
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
    }

    public JavainputmessageModel postJavainputmessageModel(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

        return createHypermedia(oHibernateController.postinputmessage(oJavainputmessageModel));
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client so as it will be able to forward the application state in a valid way.*/
    public JavainputmessageModel createHypermedia(JavainputmessageModel oJavainputmessageModel){

        /* Create hypermedia links towards this specific inputmessage resource. These must be GET and POST as it is prescribed in the meta-models.*/
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Get all inputmessages of this soapoperation", "GET", "Sibling"));
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Create a new inputmessage", "POST", "Sibling"));

        /* Then calculate the relative path to any resources that are related of this one and add the according hypermedia links to the Linklist.*/
        String oRelativePath;
        oRelativePath = oApplicationUri.getPath();
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavainputmessageModel.getinputmessageId()), oJavainputmessageModel.getname(), "GET", "Child", oJavainputmessageModel.getinputmessageId()));
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavainputmessageModel.getinputmessageId()), oJavainputmessageModel.getname(), "PUT", "Child", oJavainputmessageModel.getinputmessageId()));
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oJavainputmessageModel.getinputmessageId()), oJavainputmessageModel.getname(), "DELETE", "Child", oJavainputmessageModel.getinputmessageId()));

        /* Finally, calculate the relative path towards the resources of which this one is related.
        Then add hypermedia links for each one of them*/
        this.oJavasoapoperationModel = HibernateController.getHibernateControllerHandle().getsoapoperation(this.oJavasoapoperationModel);
        oRelativePath = String.format("soapservice/%d/%s", this.oJavasoapoperationModel.getsoapservice().getsoapserviceId(), oApplicationUri.getPath());
        int iLastSlashIndex = String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).lastIndexOf("/");
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Delete the parent JavasoapoperationModel", "DELETE", "Parent"));
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Get the parent JavasoapoperationModel", "GET", "Parent"));
        oJavainputmessageModel.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Update the JavasoapoperationModel", "PUT", "Parent"));
        return oJavainputmessageModel;
    }
}
