/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.soapoperation;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import javax.persistence.Table;
import javax.persistence.Transient;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.annotations.ForeignKey;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.outputmessage.JavaoutputmessageModel;
import eu.fp7.scase.wsat.inputmessage.JavainputmessageModel;
import eu.fp7.scase.wsat.soapservice.JavasoapserviceModel;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

import eu.fp7.scase.wsat.utilities.SetStringFieldBridge;

/* This class models the data of a soapoperation resource. It is enhanced with JAXB annotations for automated representation
parsing/marshalling as well as with Hibernate annotations for ORM transformations.*/
@XmlRootElement
@Entity
@Table(name="soapoperation")
@Indexed
public class JavasoapoperationModel{


    /* There follows a list with the properties that model the soapoperation resource, as prescribed in the service CIM*/
		@Column(name = "name")
		private String name;

		@Column(name = "description")
		@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
		private String description;

		@ElementCollection(fetch = FetchType.EAGER)
		@CollectionTable(name="soapoperationkeywords", joinColumns=@JoinColumn(name="soapoperationId"))
		@Column(name = "keywords")
		@ForeignKey(name = "fk_soapoperation_keywords")
		@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
		@FieldBridge(impl=SetStringFieldBridge.class)
		private Set<String> keywords = new HashSet<String>();

		@Id
		@GeneratedValue
		@Column(name = "soapoperationId")
		private int soapoperationId;

		// The Linklist property holds all the hypermedia links to be sent back to the client
		@Transient
		private List<HypermediaLink> linklist = new ArrayList<HypermediaLink>();

		// This property models the Many to One relationship between two resources as it is defined by the Hibernate syntax below.
		@ManyToOne(fetch = FetchType.EAGER)
		@JoinColumn(name="soapserviceId")
		@ForeignKey(name = "fk_soapservice_soapoperation")
		private JavasoapserviceModel soapservice;

		// This property models the One to Many relationship between two resources as it is defined by the Hibernate syntax below.
		@OneToMany(fetch = FetchType.EAGER, mappedBy="soapoperation",orphanRemoval=true)
		@OnDelete(action=OnDeleteAction.CASCADE)
		private Set<JavaoutputmessageModel> SetOfJavaoutputmessageModel = new HashSet<JavaoutputmessageModel>();

		// This property models the One to Many relationship between two resources as it is defined by the Hibernate syntax below.
		@OneToMany(fetch = FetchType.EAGER, mappedBy="soapoperation",orphanRemoval=true)
		@OnDelete(action=OnDeleteAction.CASCADE)
		private Set<JavainputmessageModel> SetOfJavainputmessageModel = new HashSet<JavainputmessageModel>();

    /* There follows a list of setter and getter functions.*/
	    public void setname(String name){
        	this.name = name;
    	}

	    public void setdescription(String description){
        	this.description = description;
    	}

	    public void setkeywords(Set<String> keywords){
        	this.keywords = keywords;
    	}

	    public void setsoapoperationId(int soapoperationId){
        	this.soapoperationId = soapoperationId;
    	}

	    public void setlinklist(List<HypermediaLink> linklist){
        	this.linklist = linklist;
    	}

		@XmlTransient
	    public void setsoapservice(JavasoapserviceModel soapservice){
        	this.soapservice = soapservice;
    	}

		@XmlTransient
	    public void setSetOfJavaoutputmessageModel(Set<JavaoutputmessageModel> SetOfJavaoutputmessageModel){
        	this.SetOfJavaoutputmessageModel = SetOfJavaoutputmessageModel;
    	}

		@XmlTransient
	    public void setSetOfJavainputmessageModel(Set<JavainputmessageModel> SetOfJavainputmessageModel){
        	this.SetOfJavainputmessageModel = SetOfJavainputmessageModel;
    	}

	    public String getname(){
        	return this.name;
    	}

	    public String getdescription(){
        	return this.description;
    	}

	    public Set<String> getkeywords(){
        	return this.keywords;
    	}

	    public int getsoapoperationId(){
        	return this.soapoperationId;
    	}

	    public List<HypermediaLink> getlinklist(){
        	return this.linklist;
    	}

	    public JavasoapserviceModel getsoapservice(){
        	return this.soapservice;
    	}

	    public Set<JavaoutputmessageModel> getSetOfJavaoutputmessageModel(){
        	return this.SetOfJavaoutputmessageModel;
    	}

	    public Set<JavainputmessageModel> getSetOfJavainputmessageModel(){
        	return this.SetOfJavainputmessageModel;
    	}


    /* This function deletes explicitly any collections of this resource that are stored in the database 
    and iteratively does so for any subsequent related resources.
    NOTE: this function is needed to handle erroneous handling of cascade delete of some hibernate versions.*/
    public void deleteAllCollections(Session hibernateSession){

        Query query = hibernateSession.createSQLQuery(String.format("DELETE FROM %s where %sId = %d","soapoperationkeywords".toLowerCase(),"soapoperation",this.getsoapoperationId()));
        query.executeUpdate();

        Iterator<JavaoutputmessageModel> JavaoutputmessageModelIterator = SetOfJavaoutputmessageModel.iterator();
        while(JavaoutputmessageModelIterator.hasNext()){
            JavaoutputmessageModelIterator.next().deleteAllCollections(hibernateSession);
        }

        Iterator<JavainputmessageModel> JavainputmessageModelIterator = SetOfJavainputmessageModel.iterator();
        while(JavainputmessageModelIterator.hasNext()){
            JavainputmessageModelIterator.next().deleteAllCollections(hibernateSession);
        }
    }
}
