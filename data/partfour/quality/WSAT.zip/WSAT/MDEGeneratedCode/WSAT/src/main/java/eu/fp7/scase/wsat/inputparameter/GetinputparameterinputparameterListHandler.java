/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.inputparameter;


import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import java.util.Iterator;
import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterModel;

/* This class processes GET requests for inputparameter resources and creates the hypermedia to be returned to the client*/
public class GetinputparameterinputparameterListHandler{


    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavainputparameterModel oSourceJavainputparameterModel;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public GetinputparameterinputparameterListHandler(String authHeader, int SourceinputparameterId, UriInfo oApplicationUri){
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
        oSourceJavainputparameterModel = new JavainputparameterModel();
        oSourceJavainputparameterModel.setinputparameterId(SourceinputparameterId);
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
    }

    public JavainputparameterModelManager getJavainputparameterModelManager(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

        oSourceJavainputparameterModel = oHibernateController.getinputparameterinputparameterList(oSourceJavainputparameterModel);
        return createHypermedia(oSourceJavainputparameterModel);
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client so as it will be able to forward the application state in a valid way.*/
    public JavainputparameterModelManager createHypermedia(JavainputparameterModel oJavainputparameterModel){
        JavainputparameterModelManager oJavainputparameterModelManager = new JavainputparameterModelManager();

        /* Create hypermedia links towards this specific inputparameter resource. These must be GET and POST as it is prescribed in the meta-models.*/
        oJavainputparameterModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Get all inputparameters of this inputparameter", "GET", "Sibling"));
        oJavainputparameterModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Create a new inputparameter", "POST", "Sibling"));

        /* Then calculate the relative path to any related resource of this one and add for each one a hypermedia link to the Linklist.*/
        String oRelativePath;
        oRelativePath = oApplicationUri.getPath().replaceAll("multiinputparameterManager/", "multiinputparameter/");
        Iterator<JavainputparameterModel> setIterator = oSourceJavainputparameterModel.getSetOfJavainputparameterModel().iterator();
        while(setIterator.hasNext()){
            JavainputparameterModel oNextJavainputparameterModel = new JavainputparameterModel();
            oNextJavainputparameterModel = setIterator.next();
            oJavainputparameterModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oNextJavainputparameterModel.getinputparameterId()), String.format("%s", oNextJavainputparameterModel.getname()), "GET", "Child", oNextJavainputparameterModel.getinputparameterId()));
        }

        /* Finally calculate the relative path towards the resources of which this one is related and add one hypermedia link for each one of them in the Linklist.*/
        this.oSourceJavainputparameterModel = HibernateController.getHibernateControllerHandle().getinputparameter(this.oSourceJavainputparameterModel);
		if(this.oSourceJavainputparameterModel.getinputparameter() != null){
            oRelativePath = String.format("multiinputparameter/inputparameter/%d/%s", this.oSourceJavainputparameterModel.getinputparameter().getinputparameterId(), oApplicationUri.getPath().replaceAll("multiinputparameterManager/", ""));
		}

        else		if(this.oSourceJavainputparameterModel.getinputmessage() != null){
            oRelativePath = String.format("multiinputparameter/inputmessage/%d/%s", this.oSourceJavainputparameterModel.getinputmessage().getinputmessageId(), oApplicationUri.getPath().replaceAll("multiinputparameterManager/", ""));
		}
        int iLastSlashIndex = String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).lastIndexOf("/");
        oJavainputparameterModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Delete the parent inputparameter", "DELETE", "Parent"));
        oJavainputparameterModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Get the parent inputparameter", "GET", "Parent"));
        oJavainputparameterModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Update the inputparameter", "PUT", "Parent"));
        return oJavainputparameterModelManager;
    }
}
