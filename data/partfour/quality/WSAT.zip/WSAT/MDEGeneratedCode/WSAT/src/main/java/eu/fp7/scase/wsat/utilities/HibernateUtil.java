/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.utilities;


import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;
import eu.fp7.scase.wsat.restmethod.JavarestmethodModel;
import eu.fp7.scase.wsat.soapservice.JavasoapserviceModel;
import eu.fp7.scase.wsat.outputmessage.JavaoutputmessageModel;
import eu.fp7.scase.wsat.restparameter.JavarestparameterModel;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterModel;
import eu.fp7.scase.wsat.outputparameter.JavaoutputparameterModel;
import eu.fp7.scase.wsat.inputmessage.JavainputmessageModel;
import eu.fp7.scase.wsat.resource.JavaresourceModel;
import eu.fp7.scase.wsat.account.JavaaccountModel;
import eu.fp7.scase.wsat.soapoperation.JavasoapoperationModel;
import eu.fp7.scase.wsat.restservice.JavarestserviceModel;

/* This class follows the singleton pattern in order to build once and provide a unique hibernate session instance*/

public class HibernateUtil{

    private static final SessionFactory sessionFactory = buildSessionFactory();

    private static SessionFactory buildSessionFactory(){
        try {
        /* Create the unique hibernate session. All resource models should be added here.*/
            return new AnnotationConfiguration().configure()
					.addAnnotatedClass(JavarestmethodModel.class)
					.addAnnotatedClass(JavasoapserviceModel.class)
					.addAnnotatedClass(JavaoutputmessageModel.class)
					.addAnnotatedClass(JavarestparameterModel.class)
					.addAnnotatedClass(JavainputparameterModel.class)
					.addAnnotatedClass(JavaoutputparameterModel.class)
					.addAnnotatedClass(JavainputmessageModel.class)
					.addAnnotatedClass(JavaresourceModel.class)
					.addAnnotatedClass(JavaaccountModel.class)
					.addAnnotatedClass(JavasoapoperationModel.class)
					.addAnnotatedClass(JavarestserviceModel.class)
                    .buildSessionFactory();
        }
        catch (Throwable ex){
            System.err.println("Initial SessionFactory creation failed." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static SessionFactory getSessionFactory(){
        return sessionFactory;
    }
}
