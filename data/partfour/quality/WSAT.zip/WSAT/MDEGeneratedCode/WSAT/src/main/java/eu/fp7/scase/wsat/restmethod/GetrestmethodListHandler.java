/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.restmethod;


import javax.ws.rs.core.UriInfo;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;
import com.sun.jersey.core.util.Base64;
import eu.fp7.scase.wsat.account.JavaaccountModel;

import java.util.Iterator;
import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.utilities.HibernateController;
import eu.fp7.scase.wsat.resource.JavaresourceModel;

/* This class processes GET requests for restmethod resources and creates the hypermedia to be returned to the client*/
public class GetrestmethodListHandler{

    private HibernateController oHibernateController;
    private UriInfo oApplicationUri; //Standard datatype that holds information on the URI info of this request
    private JavaresourceModel oJavaresourceModel;
	private String authHeader;
	private JavaaccountModel oAuthenticationAccount;

    public GetrestmethodListHandler(String authHeader, int resourceId, UriInfo oApplicationUri){
        this.oHibernateController = HibernateController.getHibernateControllerHandle();
        this.oApplicationUri = oApplicationUri;
        oJavaresourceModel = new JavaresourceModel();
        oJavaresourceModel.setresourceId(resourceId);
		this.authHeader = authHeader;
		this.oAuthenticationAccount = new JavaaccountModel(); 
    }

    public JavarestmethodModelManager getJavarestmethodModelManager(){

    	//check if there is a non null authentication header
    	if(authHeader == null){
    		throw new WebApplicationException(Response.Status.FORBIDDEN);
    	}
		else{
	    	//decode the auth header
    		decodeAuthorizationHeader();

        	//authenticate the user against the database
        	oAuthenticationAccount = oHibernateController.authenticateUser(oAuthenticationAccount);

			//check if the authentication failed
			if(oAuthenticationAccount == null){
        		throw new WebApplicationException(Response.Status.UNAUTHORIZED);
        	}
		}

        oJavaresourceModel = oHibernateController.getrestmethodList(oJavaresourceModel);
        return createHypermedia(oJavaresourceModel);
    }

	/* This function performs the decoding of the authentication header */
    public void decodeAuthorizationHeader()
    {
    	//check if this request has basic authentication
    	if( !authHeader.contains("Basic "))
    	{
    		throw new WebApplicationException(Response.Status.BAD_REQUEST);
    	}
    	
        authHeader = authHeader.substring("Basic ".length());
        String[] decodedHeader;
        decodedHeader = Base64.base64Decode(authHeader).split(":");
        
        if( decodedHeader == null)
        {
        	throw new WebApplicationException(Response.Status.BAD_REQUEST);
        }
        
        oAuthenticationAccount.setusername(decodedHeader[0]);
        oAuthenticationAccount.setpassword(decodedHeader[1]);
    }

    /* This function produces hypermedia links to be sent to the client so as it will be able to forward the application state in a valid way.*/
    public JavarestmethodModelManager createHypermedia(JavaresourceModel oJavaresourceModel){
        JavarestmethodModelManager oJavarestmethodModelManager = new JavarestmethodModelManager();

        /* Create hypermedia links towards this specific restmethod resource. These must be GET and POST as it is prescribed in the meta-models.*/
        oJavarestmethodModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Get all restmethods of this resource", "GET", "Sibling"));
        oJavarestmethodModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oApplicationUri.getPath()), "Create a new restmethod", "POST", "Sibling"));

        /* Then calculate the relative path to any related resource of this one and add for each one a hypermedia link to the Linklist.*/
        String oRelativePath;
        oRelativePath = oApplicationUri.getPath();
        Iterator<JavarestmethodModel> setIterator = oJavaresourceModel.getSetOfJavarestmethodModel().iterator();
        while(setIterator.hasNext()){
            JavarestmethodModel oNextJavarestmethodModel = new JavarestmethodModel();
            oNextJavarestmethodModel = setIterator.next();
            oJavarestmethodModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s/%d", oApplicationUri.getBaseUri(), oRelativePath, oNextJavarestmethodModel.getrestmethodId()), String.format("%s", oNextJavarestmethodModel.getmethodidentifier()), "GET", "Child", oNextJavarestmethodModel.getrestmethodId()));
        }

        /* Finally calculate the relative path towards the resources of which this one is related and add one hypermedia link for each one of them in the Linklist.*/
        this.oJavaresourceModel = HibernateController.getHibernateControllerHandle().getresource(this.oJavaresourceModel);
        oRelativePath = String.format("restservice/%d/%s", this.oJavaresourceModel.getrestservice().getrestserviceId(), oApplicationUri.getPath());
        int iLastSlashIndex = String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).lastIndexOf("/");
        oJavarestmethodModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Delete the parent JavaresourceModel", "DELETE", "Parent"));
        oJavarestmethodModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Get the parent JavaresourceModel", "GET", "Parent"));
        oJavarestmethodModelManager.getlinklist().add(new HypermediaLink(String.format("%s%s", oApplicationUri.getBaseUri(), oRelativePath).substring(0, iLastSlashIndex), "Update the JavaresourceModel", "PUT", "Parent"));
        return oJavarestmethodModelManager;
    }
}
