/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.restparameter;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.DefaultValue;


/* This class defines the web API of the individual restparameter resource. It may handle PUT, GET and/or DELETE requests 
   depending on the specific CIM of the service.*/

@Path("/multirestparameter")
public class JavarestparameterController{

    @Context
    private UriInfo oApplicationUri;

	/* This function handles http GET requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/restmethod/{restmethodId}/restparameter/{restparameterId}")
	@GET
	@Produces("application/JSON")
    public JavarestparameterModel getrestmethodrestparameter(@HeaderParam("authorization") String authHeader, @PathParam("restparameterId") int restparameterId){
        GetrestmethodrestparameterHandler oGetrestmethodrestparameterHandler = new GetrestmethodrestparameterHandler(authHeader, restparameterId, oApplicationUri);
        return oGetrestmethodrestparameterHandler.getJavarestparameterModel();
    }

	/* This function handles http GET requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/resource/{resourceId}/restparameter/{restparameterId}")
	@GET
	@Produces("application/JSON")
    public JavarestparameterModel getresourcerestparameter(@HeaderParam("authorization") String authHeader, @PathParam("restparameterId") int restparameterId){
        GetresourcerestparameterHandler oGetresourcerestparameterHandler = new GetresourcerestparameterHandler(authHeader, restparameterId, oApplicationUri);
        return oGetresourcerestparameterHandler.getJavarestparameterModel();
    }

	/* This function handles http PUT requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/restmethod/{restmethodId}/restparameter/{restparameterId}")
	@PUT
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavarestparameterModel putrestmethodrestparameter(@HeaderParam("authorization") String authHeader, @PathParam("restmethodId") int restmethodId, @PathParam("restparameterId") int restparameterId,  JavarestparameterModel oJavarestparameterModel){
        PutrestmethodrestparameterHandler oPutrestmethodrestparameterHandler = new PutrestmethodrestparameterHandler(authHeader, restmethodId, restparameterId, oJavarestparameterModel, oApplicationUri);
        return oPutrestmethodrestparameterHandler.putJavarestparameterModel();
    }

	/* This function handles http PUT requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/resource/{resourceId}/restparameter/{restparameterId}")
	@PUT
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavarestparameterModel putresourcerestparameter(@HeaderParam("authorization") String authHeader, @PathParam("resourceId") int resourceId, @PathParam("restparameterId") int restparameterId,  JavarestparameterModel oJavarestparameterModel){
        PutresourcerestparameterHandler oPutresourcerestparameterHandler = new PutresourcerestparameterHandler(authHeader, resourceId, restparameterId, oJavarestparameterModel, oApplicationUri);
        return oPutresourcerestparameterHandler.putJavarestparameterModel();
    }

    /* This function handles http DELETE requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/restmethod/{restmethodId}/restparameter/{restparameterId}")
	@DELETE
	@Produces("application/JSON")
    public JavarestparameterModel deleterestmethodrestparameter(@HeaderParam("authorization") String authHeader, @PathParam("restparameterId") int restparameterId){
        DeleterestmethodrestparameterHandler oDeleterestmethodrestparameterHandler = new DeleterestmethodrestparameterHandler(authHeader, restparameterId, oApplicationUri);
        return oDeleterestmethodrestparameterHandler.deleteJavarestparameterModel();
    }

    /* This function handles http DELETE requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/resource/{resourceId}/restparameter/{restparameterId}")
	@DELETE
	@Produces("application/JSON")
    public JavarestparameterModel deleteresourcerestparameter(@HeaderParam("authorization") String authHeader, @PathParam("restparameterId") int restparameterId){
        DeleteresourcerestparameterHandler oDeleteresourcerestparameterHandler = new DeleteresourcerestparameterHandler(authHeader, restparameterId, oApplicationUri);
        return oDeleteresourcerestparameterHandler.deleteJavarestparameterModel();
    }
}

