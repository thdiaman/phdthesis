/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.artefactsearch;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam; 

/* JavaAlgoartefactsearchController class is responsible to handle incoming HTTP requests for the artefactsearch resource. More specifically
this resource controller handles search requests by keyword for the following resources/properties:
From resource JavarestmethodModel :
-- methoddescription
-- methodidentifier
-- methodkeywords
From resource JavasoapserviceModel :
-- description
-- keywords
From resource JavarestparameterModel :
-- parameterdescription
From resource JavainputparameterModel :
-- keywords
From resource JavaoutputparameterModel :
-- keywords
From resource JavaresourceModel :
-- resourcedescription
-- resourcekeywords
From resource JavasoapoperationModel :
-- description
-- keywords
*/
@Path("/Algoartefactsearch")
public class JavaAlgoartefactsearchController{

    @Context
    private UriInfo oApplicationUri;

	/* This function handles http  requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/")
	@GET
	@Produces("application/JSON")
    public JavaAlgoartefactsearchModel getartefactsearch( @HeaderParam("authorization") String authHeader, @QueryParam("searchKeyword") String searchKeyword, @QueryParam("searchRestmethodMethoddescription") String searchRestmethodMethoddescription, @QueryParam("searchRestmethodMethodidentifier") String searchRestmethodMethodidentifier, @QueryParam("searchRestmethodMethodkeywords") String searchRestmethodMethodkeywords, @QueryParam("searchSoapserviceDescription") String searchSoapserviceDescription, @QueryParam("searchSoapserviceKeywords") String searchSoapserviceKeywords, @QueryParam("searchRestparameterParameterdescription") String searchRestparameterParameterdescription, @QueryParam("searchInputparameterKeywords") String searchInputparameterKeywords, @QueryParam("searchOutputparameterKeywords") String searchOutputparameterKeywords, @QueryParam("searchResourceResourcedescription") String searchResourceResourcedescription, @QueryParam("searchResourceResourcekeywords") String searchResourceResourcekeywords, @QueryParam("searchSoapoperationDescription") String searchSoapoperationDescription, @QueryParam("searchSoapoperationKeywords") String searchSoapoperationKeywords){

		//create a new GetartefactsearchHandler
		GetartefactsearchHandler oGetartefactsearchHandler = new GetartefactsearchHandler( authHeader, searchKeyword, searchRestmethodMethoddescription, searchRestmethodMethodidentifier, searchRestmethodMethodkeywords, searchSoapserviceDescription, searchSoapserviceKeywords, searchRestparameterParameterdescription, searchInputparameterKeywords, searchOutputparameterKeywords, searchResourceResourcedescription, searchResourceResourcekeywords, searchSoapoperationDescription, searchSoapoperationKeywords, oApplicationUri);
		return oGetartefactsearchHandler.getartefactsearch();

    }
}
