/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.utilities;


import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import eu.fp7.scase.wsat.restmethod.JavarestmethodController;
import eu.fp7.scase.wsat.soapservice.JavasoapserviceController;
import eu.fp7.scase.wsat.outputmessage.JavaoutputmessageController;
import eu.fp7.scase.wsat.restparameter.JavarestparameterController;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterController;
import eu.fp7.scase.wsat.outputparameter.JavaoutputparameterController;
import eu.fp7.scase.wsat.inputmessage.JavainputmessageController;
import eu.fp7.scase.wsat.resource.JavaresourceController;
import eu.fp7.scase.wsat.account.JavaaccountController;
import eu.fp7.scase.wsat.soapoperation.JavasoapoperationController;
import eu.fp7.scase.wsat.restservice.JavarestserviceController;
import eu.fp7.scase.wsat.restmethod.JavarestmethodControllerManager;
import eu.fp7.scase.wsat.soapservice.JavasoapserviceControllerManager;
import eu.fp7.scase.wsat.outputmessage.JavaoutputmessageControllerManager;
import eu.fp7.scase.wsat.restparameter.JavarestparameterControllerManager;
import eu.fp7.scase.wsat.inputparameter.JavainputparameterControllerManager;
import eu.fp7.scase.wsat.outputparameter.JavaoutputparameterControllerManager;
import eu.fp7.scase.wsat.inputmessage.JavainputmessageControllerManager;
import eu.fp7.scase.wsat.resource.JavaresourceControllerManager;
import eu.fp7.scase.wsat.account.JavaaccountControllerManager;
import eu.fp7.scase.wsat.soapoperation.JavasoapoperationControllerManager;
import eu.fp7.scase.wsat.restservice.JavarestserviceControllerManager;
import eu.fp7.scase.wsat.wadlparse.JavaAlgowadlparseController;
import eu.fp7.scase.wsat.wsdlparse.JavaAlgowsdlparseController;
import eu.fp7.scase.wsat.artefactsearch.JavaAlgoartefactsearchController;

/* This class is responsible to publish any resource controllers that can handle incoming HTTP requests
to the web service container (Jetty etc)*/

@ApplicationPath("/api/")
public class JAXRSPublisher extends Application{

    public JAXRSPublisher(){}

    /* This function returns to the container (Jetty, Tomcat etc) the classes that expose any web API*/
    @Override
    public Set<Class<?>> getClasses(){
        HashSet<Class<?>> SetOfClasses = new HashSet<Class<?>>();
		SetOfClasses.add(JavarestmethodController.class);
		SetOfClasses.add(JavasoapserviceController.class);
		SetOfClasses.add(JavaoutputmessageController.class);
		SetOfClasses.add(JavarestparameterController.class);
		SetOfClasses.add(JavainputparameterController.class);
		SetOfClasses.add(JavaoutputparameterController.class);
		SetOfClasses.add(JavainputmessageController.class);
		SetOfClasses.add(JavaresourceController.class);
		SetOfClasses.add(JavaaccountController.class);
		SetOfClasses.add(JavasoapoperationController.class);
		SetOfClasses.add(JavarestserviceController.class);
		SetOfClasses.add(JavarestmethodControllerManager.class);
		SetOfClasses.add(JavasoapserviceControllerManager.class);
		SetOfClasses.add(JavaoutputmessageControllerManager.class);
		SetOfClasses.add(JavarestparameterControllerManager.class);
		SetOfClasses.add(JavainputparameterControllerManager.class);
		SetOfClasses.add(JavaoutputparameterControllerManager.class);
		SetOfClasses.add(JavainputmessageControllerManager.class);
		SetOfClasses.add(JavaresourceControllerManager.class);
		SetOfClasses.add(JavaaccountControllerManager.class);
		SetOfClasses.add(JavasoapoperationControllerManager.class);
		SetOfClasses.add(JavarestserviceControllerManager.class);
		SetOfClasses.add(JavaAlgowadlparseController.class);
		SetOfClasses.add(JavaAlgowsdlparseController.class);
		SetOfClasses.add(JavaAlgoartefactsearchController.class);

        return SetOfClasses;
    }

    @Override
    public Set<Object> getSingletons(){
        return new HashSet<Object>();
    }
}
