/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.restparameter;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.Table;
import javax.persistence.Transient;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.annotations.ForeignKey;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.restmethod.JavarestmethodModel;
import eu.fp7.scase.wsat.resource.JavaresourceModel;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

import eu.fp7.scase.wsat.utilities.SetStringFieldBridge;

/* This class models the data of a restparameter resource. It is enhanced with JAXB annotations for automated representation
parsing/marshalling as well as with Hibernate annotations for ORM transformations.*/
@XmlRootElement
@Entity
@Table(name="restparameter")
@Indexed
public class JavarestparameterModel{


    /* There follows a list with the properties that model the restparameter resource, as prescribed in the service CIM*/
		@Column(name = "parametertype")
		private String parametertype;

		@ElementCollection(fetch = FetchType.EAGER)
		@CollectionTable(name="restparameterparametervalueoption", joinColumns=@JoinColumn(name="restparameterId"))
		@Column(name = "parametervalueoption")
		@ForeignKey(name = "fk_restparameter_parametervalueoption")
		private Set<String> parametervalueoption = new HashSet<String>();

		@Column(name = "parameterdescription")
		@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
		private String parameterdescription;

		@Column(name = "parametername")
		private String parametername;

		@Column(name = "parameterrequired")
		private String parameterrequired;

		@Column(name = "parameterstyle")
		private String parameterstyle;

		@Column(name = "parameterdirection")
		private String parameterdirection;

		@Column(name = "parameterdefault")
		private String parameterdefault;

		@Id
		@GeneratedValue
		@Column(name = "restparameterId")
		private int restparameterId;

		// The Linklist property holds all the hypermedia links to be sent back to the client
		@Transient
		private List<HypermediaLink> linklist = new ArrayList<HypermediaLink>();

		// This property models the Many to One relationship between two resources as it is defined by the Hibernate syntax below.
		@ManyToOne(fetch = FetchType.EAGER)
		@JoinColumn(name="restmethodId")
		@ForeignKey(name = "fk_restmethod_restparameter")
		private JavarestmethodModel restmethod;

		// This property models the Many to One relationship between two resources as it is defined by the Hibernate syntax below.
		@ManyToOne(fetch = FetchType.EAGER)
		@JoinColumn(name="resourceId")
		@ForeignKey(name = "fk_resource_restparameter")
		private JavaresourceModel resource;

    /* There follows a list of setter and getter functions.*/
	    public void setparametertype(String parametertype){
        	this.parametertype = parametertype;
    	}

	    public void setparametervalueoption(Set<String> parametervalueoption){
        	this.parametervalueoption = parametervalueoption;
    	}

	    public void setparameterdescription(String parameterdescription){
        	this.parameterdescription = parameterdescription;
    	}

	    public void setparametername(String parametername){
        	this.parametername = parametername;
    	}

	    public void setparameterrequired(String parameterrequired){
        	this.parameterrequired = parameterrequired;
    	}

	    public void setparameterstyle(String parameterstyle){
        	this.parameterstyle = parameterstyle;
    	}

	    public void setparameterdirection(String parameterdirection){
        	this.parameterdirection = parameterdirection;
    	}

	    public void setparameterdefault(String parameterdefault){
        	this.parameterdefault = parameterdefault;
    	}

	    public void setrestparameterId(int restparameterId){
        	this.restparameterId = restparameterId;
    	}

	    public void setlinklist(List<HypermediaLink> linklist){
        	this.linklist = linklist;
    	}

		@XmlTransient
	    public void setrestmethod(JavarestmethodModel restmethod){
        	this.restmethod = restmethod;
    	}

		@XmlTransient
	    public void setresource(JavaresourceModel resource){
        	this.resource = resource;
    	}

	    public String getparametertype(){
        	return this.parametertype;
    	}

	    public Set<String> getparametervalueoption(){
        	return this.parametervalueoption;
    	}

	    public String getparameterdescription(){
        	return this.parameterdescription;
    	}

	    public String getparametername(){
        	return this.parametername;
    	}

	    public String getparameterrequired(){
        	return this.parameterrequired;
    	}

	    public String getparameterstyle(){
        	return this.parameterstyle;
    	}

	    public String getparameterdirection(){
        	return this.parameterdirection;
    	}

	    public String getparameterdefault(){
        	return this.parameterdefault;
    	}

	    public int getrestparameterId(){
        	return this.restparameterId;
    	}

	    public List<HypermediaLink> getlinklist(){
        	return this.linklist;
    	}

	    public JavarestmethodModel getrestmethod(){
        	return this.restmethod;
    	}

	    public JavaresourceModel getresource(){
        	return this.resource;
    	}


    /* This function deletes explicitly any collections of this resource that are stored in the database 
    and iteratively does so for any subsequent related resources.
    NOTE: this function is needed to handle erroneous handling of cascade delete of some hibernate versions.*/
    public void deleteAllCollections(Session hibernateSession){

        Query query = hibernateSession.createSQLQuery(String.format("DELETE FROM %s where %sId = %d","restparameterparametervalueoption".toLowerCase(),"restparameter",this.getrestparameterId()));
        query.executeUpdate();

    }
}
