/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.inputparameter;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.DefaultValue;


/* This class defines the web API of the individual inputparameter resource. It may handle PUT, GET and/or DELETE requests 
   depending on the specific CIM of the service.*/

@Path("/multiinputparameter")
public class JavainputparameterController{

    @Context
    private UriInfo oApplicationUri;

	/* This function handles http GET requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputparameter/{inputparameterId}/inputparameter/{targetinputparameterId}")
	@GET
	@Produces("application/JSON")
    public JavainputparameterModel getinputparameterinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("targetinputparameterId") int targetinputparameterId){
        GetinputparameterinputparameterHandler oGetinputparameterinputparameterHandler = new GetinputparameterinputparameterHandler(authHeader, targetinputparameterId, oApplicationUri);
        return oGetinputparameterinputparameterHandler.getJavainputparameterModel();
    }

	/* This function handles http GET requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputmessage/{inputmessageId}/inputparameter/{inputparameterId}")
	@GET
	@Produces("application/JSON")
    public JavainputparameterModel getinputmessageinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("inputparameterId") int inputparameterId){
        GetinputmessageinputparameterHandler oGetinputmessageinputparameterHandler = new GetinputmessageinputparameterHandler(authHeader, inputparameterId, oApplicationUri);
        return oGetinputmessageinputparameterHandler.getJavainputparameterModel();
    }

	/* This function handles http PUT requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputparameter/{inputparameterId}/inputparameter/{targetinputparameterId}")
	@PUT
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavainputparameterModel putinputparameterinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("inputparameterId") int inputparameterId, @PathParam("targetinputparameterId") int targetinputparameterId,  JavainputparameterModel oJavainputparameterModel){
        PutinputparameterinputparameterHandler oPutinputparameterinputparameterHandler = new PutinputparameterinputparameterHandler(authHeader, inputparameterId, targetinputparameterId, oJavainputparameterModel, oApplicationUri);
        return oPutinputparameterinputparameterHandler.putJavainputparameterModel();
    }

	/* This function handles http PUT requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputmessage/{inputmessageId}/inputparameter/{inputparameterId}")
	@PUT
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavainputparameterModel putinputmessageinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("inputmessageId") int inputmessageId, @PathParam("inputparameterId") int inputparameterId,  JavainputparameterModel oJavainputparameterModel){
        PutinputmessageinputparameterHandler oPutinputmessageinputparameterHandler = new PutinputmessageinputparameterHandler(authHeader, inputmessageId, inputparameterId, oJavainputparameterModel, oApplicationUri);
        return oPutinputmessageinputparameterHandler.putJavainputparameterModel();
    }

    /* This function handles http DELETE requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputparameter/{inputparameterId}/inputparameter/{targetinputparameterId}")
	@DELETE
	@Produces("application/JSON")
    public JavainputparameterModel deleteinputparameterinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("targetinputparameterId") int targetinputparameterId){
        DeleteinputparameterinputparameterHandler oDeleteinputparameterinputparameterHandler = new DeleteinputparameterinputparameterHandler(authHeader, targetinputparameterId, oApplicationUri);
        return oDeleteinputparameterinputparameterHandler.deleteJavainputparameterModel();
    }

    /* This function handles http DELETE requests  
    and returns any response formatted as stated in the @Produces JAX-RS annotation below.*/
	@Path("/inputmessage/{inputmessageId}/inputparameter/{inputparameterId}")
	@DELETE
	@Produces("application/JSON")
    public JavainputparameterModel deleteinputmessageinputparameter(@HeaderParam("authorization") String authHeader, @PathParam("inputparameterId") int inputparameterId){
        DeleteinputmessageinputparameterHandler oDeleteinputmessageinputparameterHandler = new DeleteinputmessageinputparameterHandler(authHeader, inputparameterId, oApplicationUri);
        return oDeleteinputmessageinputparameterHandler.deleteJavainputparameterModel();
    }
}

