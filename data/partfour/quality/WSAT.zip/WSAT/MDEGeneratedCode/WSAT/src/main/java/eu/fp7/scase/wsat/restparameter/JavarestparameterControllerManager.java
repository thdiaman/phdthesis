/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.restparameter;


import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.DefaultValue;


/* This class defines the web API of the manager restparameter resource. It handles POST and GET HTTP requests, as it is prescribed by the meta-models.*/
@Path("/multirestparameterManager")
public class JavarestparameterControllerManager{

    @Context
    private UriInfo oApplicationUri;

	/* This function handles POST requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/restmethod/{restmethodId}/restparameter/")
	@POST
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavarestparameterModel postrestmethodrestparameter(@HeaderParam("authorization") String authHeader, @PathParam("restmethodId")int restmethodId, JavarestparameterModel oJavarestparameterModel){
        PostrestmethodrestparameterHandler oPostrestmethodrestparameterHandler = new PostrestmethodrestparameterHandler(authHeader, restmethodId, oJavarestparameterModel, oApplicationUri);
        return oPostrestmethodrestparameterHandler.postJavarestparameterModel();
    }

	/* This function handles POST requests that are sent with any media type stated in the @Consumes JAX-RS annotation below 
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/resource/{resourceId}/restparameter/")
	@POST
	@Produces("application/JSON")
	@Consumes("application/JSON")
    public JavarestparameterModel postresourcerestparameter(@HeaderParam("authorization") String authHeader, @PathParam("resourceId")int resourceId, JavarestparameterModel oJavarestparameterModel){
        PostresourcerestparameterHandler oPostresourcerestparameterHandler = new PostresourcerestparameterHandler(authHeader, resourceId, oJavarestparameterModel, oApplicationUri);
        return oPostresourcerestparameterHandler.postJavarestparameterModel();
    }

    /* This function handles GET requests  
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/restmethod/{restmethodId}/restparameter/")
	@GET
	@Produces("application/JSON")
    public JavarestparameterModelManager getrestmethodrestparameterList(@HeaderParam("authorization") String authHeader, @PathParam("restmethodId")int restmethodId){
        GetrestmethodrestparameterListHandler oGetrestmethodrestparameterListHandler = new GetrestmethodrestparameterListHandler(authHeader, restmethodId, oApplicationUri);
        return oGetrestmethodrestparameterListHandler.getJavarestparameterModelManager();
    }

    /* This function handles GET requests  
     and returns any response in any media type stated in the @Produces JAX-RS annotation below.*/
	@Path("/resource/{resourceId}/restparameter/")
	@GET
	@Produces("application/JSON")
    public JavarestparameterModelManager getresourcerestparameterList(@HeaderParam("authorization") String authHeader, @PathParam("resourceId")int resourceId){
        GetresourcerestparameterListHandler oGetresourcerestparameterListHandler = new GetresourcerestparameterListHandler(authHeader, resourceId, oApplicationUri);
        return oGetresourcerestparameterListHandler.getJavarestparameterModelManager();
    }

}
