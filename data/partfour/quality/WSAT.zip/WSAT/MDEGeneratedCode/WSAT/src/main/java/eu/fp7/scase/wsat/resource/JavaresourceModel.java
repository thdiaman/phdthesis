/*
 * ARISTOSTLE UNIVERSITY OF THESSALONIKI
 * Copyright (C) 2015
 * Aristotle University of Thessaloniki
 * Department of Electrical & Computer Engineering
 * Division of Electronics & Computer Engineering
 * Intelligent Systems & Software Engineering Lab
 *
 * Project             : WSAT
 * WorkFile            : 
 * Compiler            : 
 * File Description    : 
 * Document Description: 
* Related Documents	   : 
* Note				   : 
* Programmer		   : RESTful MDE Engine created by Christoforos Zolotas
* Contact			   : christopherzolotas@issel.ee.auth.gr
*/


package eu.fp7.scase.wsat.resource;


import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.ElementCollection;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;
import javax.persistence.Table;
import javax.persistence.Transient;

import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.annotations.ForeignKey;

import eu.fp7.scase.wsat.utilities.HypermediaLink;
import eu.fp7.scase.wsat.restmethod.JavarestmethodModel;
import eu.fp7.scase.wsat.restparameter.JavarestparameterModel;
import eu.fp7.scase.wsat.restservice.JavarestserviceModel;

import org.hibernate.search.annotations.Analyze;
import org.hibernate.search.annotations.Field;
import org.hibernate.search.annotations.FieldBridge;
import org.hibernate.search.annotations.Index;
import org.hibernate.search.annotations.Indexed;
import org.hibernate.search.annotations.IndexedEmbedded;
import org.hibernate.search.annotations.Store;

import eu.fp7.scase.wsat.utilities.SetStringFieldBridge;

/* This class models the data of a resource resource. It is enhanced with JAXB annotations for automated representation
parsing/marshalling as well as with Hibernate annotations for ORM transformations.*/
@XmlRootElement
@Entity
@Table(name="resource")
@Indexed
public class JavaresourceModel{


    /* There follows a list with the properties that model the resource resource, as prescribed in the service CIM*/
		@Column(name = "relativeuri")
		private String relativeuri;

		@Column(name = "resourcename")
		private String resourcename;

		@Column(name = "resourcedescription")
		@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
		private String resourcedescription;

		@ElementCollection(fetch = FetchType.EAGER)
		@CollectionTable(name="resourceresourcekeywords", joinColumns=@JoinColumn(name="resourceId"))
		@Column(name = "resourcekeywords")
		@ForeignKey(name = "fk_resource_resourcekeywords")
		@Field(index=Index.YES, analyze=Analyze.YES, store=Store.NO)
		@FieldBridge(impl=SetStringFieldBridge.class)
		private Set<String> resourcekeywords = new HashSet<String>();

		@Id
		@GeneratedValue
		@Column(name = "resourceId")
		private int resourceId;

		// The Linklist property holds all the hypermedia links to be sent back to the client
		@Transient
		private List<HypermediaLink> linklist = new ArrayList<HypermediaLink>();

		// This property models the Many to One relationship between two resources as it is defined by the Hibernate syntax below.
		@ManyToOne(fetch = FetchType.EAGER)
		@JoinColumn(name="restserviceId")
		@ForeignKey(name = "fk_restservice_resource")
		private JavarestserviceModel restservice;

		// This property models the One to Many relationship between two resources as it is defined by the Hibernate syntax below.
		@OneToMany(fetch = FetchType.EAGER, mappedBy="resource",orphanRemoval=true)
		@OnDelete(action=OnDeleteAction.CASCADE)
		private Set<JavarestmethodModel> SetOfJavarestmethodModel = new HashSet<JavarestmethodModel>();

		// This property models the One to Many relationship between two resources as it is defined by the Hibernate syntax below.
		@OneToMany(fetch = FetchType.EAGER, mappedBy="resource",orphanRemoval=true)
		@OnDelete(action=OnDeleteAction.CASCADE)
		private Set<JavarestparameterModel> SetOfJavarestparameterModel = new HashSet<JavarestparameterModel>();

    /* There follows a list of setter and getter functions.*/
	    public void setrelativeuri(String relativeuri){
        	this.relativeuri = relativeuri;
    	}

	    public void setresourcename(String resourcename){
        	this.resourcename = resourcename;
    	}

	    public void setresourcedescription(String resourcedescription){
        	this.resourcedescription = resourcedescription;
    	}

	    public void setresourcekeywords(Set<String> resourcekeywords){
        	this.resourcekeywords = resourcekeywords;
    	}

	    public void setresourceId(int resourceId){
        	this.resourceId = resourceId;
    	}

	    public void setlinklist(List<HypermediaLink> linklist){
        	this.linklist = linklist;
    	}

		@XmlTransient
	    public void setrestservice(JavarestserviceModel restservice){
        	this.restservice = restservice;
    	}

		@XmlTransient
	    public void setSetOfJavarestmethodModel(Set<JavarestmethodModel> SetOfJavarestmethodModel){
        	this.SetOfJavarestmethodModel = SetOfJavarestmethodModel;
    	}

		@XmlTransient
	    public void setSetOfJavarestparameterModel(Set<JavarestparameterModel> SetOfJavarestparameterModel){
        	this.SetOfJavarestparameterModel = SetOfJavarestparameterModel;
    	}

	    public String getrelativeuri(){
        	return this.relativeuri;
    	}

	    public String getresourcename(){
        	return this.resourcename;
    	}

	    public String getresourcedescription(){
        	return this.resourcedescription;
    	}

	    public Set<String> getresourcekeywords(){
        	return this.resourcekeywords;
    	}

	    public int getresourceId(){
        	return this.resourceId;
    	}

	    public List<HypermediaLink> getlinklist(){
        	return this.linklist;
    	}

	    public JavarestserviceModel getrestservice(){
        	return this.restservice;
    	}

	    public Set<JavarestmethodModel> getSetOfJavarestmethodModel(){
        	return this.SetOfJavarestmethodModel;
    	}

	    public Set<JavarestparameterModel> getSetOfJavarestparameterModel(){
        	return this.SetOfJavarestparameterModel;
    	}


    /* This function deletes explicitly any collections of this resource that are stored in the database 
    and iteratively does so for any subsequent related resources.
    NOTE: this function is needed to handle erroneous handling of cascade delete of some hibernate versions.*/
    public void deleteAllCollections(Session hibernateSession){

        Query query = hibernateSession.createSQLQuery(String.format("DELETE FROM %s where %sId = %d","resourceresourcekeywords".toLowerCase(),"resource",this.getresourceId()));
        query.executeUpdate();

        Iterator<JavarestmethodModel> JavarestmethodModelIterator = SetOfJavarestmethodModel.iterator();
        while(JavarestmethodModelIterator.hasNext()){
            JavarestmethodModelIterator.next().deleteAllCollections(hibernateSession);
        }

        Iterator<JavarestparameterModel> JavarestparameterModelIterator = SetOfJavarestparameterModel.iterator();
        while(JavarestparameterModelIterator.hasNext()){
            JavarestparameterModelIterator.next().deleteAllCollections(hibernateSession);
        }
    }
}
