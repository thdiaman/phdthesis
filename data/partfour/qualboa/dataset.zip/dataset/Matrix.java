public class Matrix {
    public Matrix(int i, int j);
    public void set(int i, int j, double value);
    public double get(int i, int j);
    public Matrix multiply(Matrix matrix);
}
