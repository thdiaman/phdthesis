public class ShoppingCart {
    public int getItemCount();
    public double getBalance();
    public void addItem(Product product);
    public void empty();
    public void removeItem(Product product);
}
