public class MortgageCalculator {
    public void setRate(double rate);
    public void setPrincipal(double principal);
    public void setYears(int years);
    public double getMonthlyPayment();
}
