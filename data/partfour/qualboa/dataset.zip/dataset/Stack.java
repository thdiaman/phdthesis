public class Stack {
    public void push(Object element);
    public Object pop();
}
